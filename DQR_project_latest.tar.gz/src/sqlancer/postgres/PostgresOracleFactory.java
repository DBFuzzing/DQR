package sqlancer.postgres;

import java.sql.SQLException;

import sqlancer.OracleFactory;
import sqlancer.common.oracle.TestOracle;
import sqlancer.postgres.oracle.PostgresTimeEquivalenceOracle;

public enum PostgresOracleFactory implements OracleFactory<PostgresGlobalState> {
    TIME_EQUIV {
        @Override
        public TestOracle<PostgresGlobalState> create(PostgresGlobalState globalState) throws SQLException {
            return new PostgresTimeEquivalenceOracle(globalState);
        }
    };

}
