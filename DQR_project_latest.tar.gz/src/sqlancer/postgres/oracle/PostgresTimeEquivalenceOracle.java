package sqlancer.postgres.oracle;

import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

import sqlancer.ComparatorHelper;
import sqlancer.IgnoreMeException;
import sqlancer.Randomly;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;
import sqlancer.postgres.PostgresGlobalState;
import sqlancer.postgres.PostgresSchema.PostgresColumn;
import sqlancer.postgres.PostgresSchema.PostgresDataType;
import sqlancer.postgres.PostgresSchema.PostgresTable;
import sqlancer.postgres.PostgresSchema.PostgresTables;
import sqlancer.postgres.PostgresVisitor;
import sqlancer.postgres.gen.PostgresCommon;
import sqlancer.postgres.gen.PostgresExpressionGenerator;
import sqlancer.postgres.ast.PostgresAggregate;
import sqlancer.postgres.ast.PostgresBetweenOperation;
import sqlancer.postgres.ast.PostgresBinaryArithmeticOperation;
import sqlancer.postgres.ast.PostgresBinaryBitOperation;
import sqlancer.postgres.ast.PostgresBinaryComparisonOperation;
import sqlancer.postgres.ast.PostgresBinaryLogicalOperation;
import sqlancer.postgres.ast.PostgresBinaryRangeOperation;
import sqlancer.postgres.ast.PostgresCastOperation;
import sqlancer.postgres.ast.PostgresCollate;
import sqlancer.postgres.ast.PostgresColumnReference;
import sqlancer.postgres.ast.PostgresColumnValue;
import sqlancer.postgres.ast.PostgresConcatOperation;
import sqlancer.postgres.ast.PostgresConstant;
import sqlancer.postgres.ast.PostgresExpression;
import sqlancer.postgres.ast.PostgresFunction;
import sqlancer.postgres.ast.PostgresInOperation;
import sqlancer.postgres.ast.PostgresJoin;
import sqlancer.postgres.ast.PostgresLikeOperation;
import sqlancer.postgres.ast.PostgresOrderByTerm;
import sqlancer.postgres.ast.PostgresPOSIXRegularExpression;
import sqlancer.postgres.ast.PostgresPostfixOperation;
import sqlancer.postgres.ast.PostgresPostfixText;
import sqlancer.postgres.ast.PostgresPrefixOperation;
import sqlancer.postgres.ast.PostgresSelect;
import sqlancer.postgres.ast.PostgresSimilarTo;
import sqlancer.postgres.ast.PostgresTableReference;
import sqlancer.postgres.ast.PostgresWindowFunction;

public class PostgresTimeEquivalenceOracle implements TestOracle<PostgresGlobalState> {

    private enum Rule {
        WHERE_TO_SUBQUERY, EXISTS_TO_SUBQUERY, HAVING_TO_SUBQUERY
    }

    private final PostgresGlobalState state;
    private final ExpectedErrors errors = new ExpectedErrors();

    public PostgresTimeEquivalenceOracle(PostgresGlobalState state) {
        this.state = state;
        PostgresCommon.addCommonExpressionErrors(errors);
        PostgresCommon.addCommonFetchErrors(errors);
        // PG < 12 does not support WITH ... AS MATERIALIZED; tolerate the syntax error.
        errors.add("syntax error at or near \"MATERIALIZED\"");
    }

    @Override
    public void check() throws SQLException {
        PostgresTables tables = state.getSchema().getRandomTableNonEmptyTables();
        List<PostgresTable> tableList = tables.getTables();
        if (tableList.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<PostgresColumn> columns = tables.getColumns();
        PostgresExpressionGenerator gen = new PostgresExpressionGenerator(state).setColumns(columns);

        Rule rule = Randomly.fromOptions(Rule.values());
        switch (rule) {
        case WHERE_TO_SUBQUERY:
            checkWhereToSubquery(gen, tableList, columns);
            break;
        case EXISTS_TO_SUBQUERY:
            checkExistsToSubquery(tableList);
            break;
        case HAVING_TO_SUBQUERY:
            checkHavingToSubquery(tableList, columns);
            break;
        default:
            throw new AssertionError(rule);
        }
    }

    // ==================== WHERE_TO_SUBQUERY ====================

    private void checkWhereToSubquery(PostgresExpressionGenerator gen, List<PostgresTable> tables,
            List<PostgresColumn> columns) throws SQLException {
        PostgresExpression predicate = generateCompoundPredicate(gen);
        String predicateString = PostgresVisitor.asString(predicate);
        String signatureExpr = buildSignatureExpression(columns, gen);
        String fromClause = buildFromClause(tables);

        String baseQuery = "SELECT " + signatureExpr + " FROM " + fromClause + " WHERE " + predicateString;
        String innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + predicateString + ") AS ref1 FROM "
                + fromClause;
        String movedQuery = "WITH s AS MATERIALIZED (" + innerQuery + ") SELECT ref0 FROM s WHERE ref1";

        compareResults(baseQuery, movedQuery);
    }

    // ==================== EXISTS_TO_SUBQUERY ====================

    private void checkExistsToSubquery(List<PostgresTable> outerTables) throws SQLException {
        List<PostgresColumn> outerColumns = outerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        if (outerColumns.isEmpty()) {
            throw new IgnoreMeException();
        }

        List<PostgresTable> innerTables = Randomly.nonEmptySubset(state.getSchema().getDatabaseTables());
        List<PostgresColumn> innerColumns = innerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        if (innerColumns.isEmpty()) {
            throw new IgnoreMeException();
        }
        PostgresExpressionGenerator innerGen = new PostgresExpressionGenerator(state).setColumns(innerColumns);
        PostgresExpression innerPredicate = generateSafeScalarExpression(innerGen);

        String innerFrom = buildFromClause(innerTables);
        String innerPredicateString = PostgresVisitor.asString(innerPredicate);
        String existsString = "EXISTS (SELECT 1 FROM " + innerFrom + " WHERE " + innerPredicateString + ")";

        PostgresExpressionGenerator outerGen = new PostgresExpressionGenerator(state).setColumns(outerColumns);
        String signatureExpr = buildSignatureExpression(outerColumns, outerGen);
        String outerFrom = buildFromClause(outerTables);

        String outerPredicateString = Randomly.getBoolean()
                ? PostgresVisitor.asString(generateCompoundPredicate(outerGen))
                : null;

        String wherePart = outerPredicateString == null ? existsString
                : "(" + existsString + ") AND (" + outerPredicateString + ")";
        String baseQuery = "SELECT " + signatureExpr + " FROM " + outerFrom + " WHERE " + wherePart;

        StringBuilder innerSelect = new StringBuilder("SELECT ").append(signatureExpr)
                .append(" AS ref0, (").append(existsString).append(") AS ref1");
        if (outerPredicateString != null) {
            innerSelect.append(", (").append(outerPredicateString).append(") AS ref2");
        }
        innerSelect.append(" FROM ").append(outerFrom);

        String filterPart = outerPredicateString == null ? "ref1" : "ref1 AND ref2";
        String movedQuery = "WITH s AS MATERIALIZED (" + innerSelect + ") SELECT ref0 FROM s WHERE " + filterPart;

        compareResults(baseQuery, movedQuery);
    }

    // ==================== HAVING_TO_SUBQUERY ====================

    private void checkHavingToSubquery(List<PostgresTable> tables, List<PostgresColumn> columns) throws SQLException {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<PostgresColumn> groupByColumns = Randomly.nonEmptySubset(columns);
        PostgresExpressionGenerator havingGen = new PostgresExpressionGenerator(state).setColumns(groupByColumns)
                .allowAggregates(true);
        PostgresExpression havingPredicate = generateSafeScalarHavingExpression(havingGen);
        String havingString = PostgresVisitor.asString(havingPredicate);

        PostgresExpressionGenerator whereGen = new PostgresExpressionGenerator(state).setColumns(columns);
        String whereString = Randomly.getBoolean()
                ? PostgresVisitor.asString(generateCompoundPredicate(whereGen))
                : null;

        String signatureExpr = buildSignatureExpression(columns, whereGen);
        String fromClause = buildFromClause(tables);
        String groupByClause = groupByColumns.stream().map(PostgresColumn::getFullQualifiedName)
                .collect(Collectors.joining(", "));
        String wherePart = whereString == null ? "" : " WHERE " + whereString;

        String baseQuery = "SELECT " + signatureExpr + " FROM " + fromClause + wherePart
                + " GROUP BY " + groupByClause + " HAVING " + havingString;

        String innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + havingString + ") AS ref1 FROM "
                + fromClause + wherePart + " GROUP BY " + groupByClause;
        String movedQuery = "WITH s AS MATERIALIZED (" + innerQuery + ") SELECT ref0 FROM s WHERE ref1";

        compareResults(baseQuery, movedQuery);
    }

    // ==================== Helpers ====================

    private void compareResults(String baseQuery, String movedQuery) throws SQLException {
        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private String buildSignatureExpression(List<PostgresColumn> columns, PostgresExpressionGenerator gen) {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < columns.size(); i++) {
            if (i > 0) {
                sb.append(" || '#' || ");
            }
            sb.append("quote_nullable(").append(columns.get(i).getFullQualifiedName()).append(")");
        }
        if (gen != null && Randomly.getBoolean()) {
            PostgresExpression extra = generateSafeScalarExpression(gen);
            sb.append(" || '#' || quote_nullable(").append(PostgresVisitor.asString(extra)).append(")");
        }
        return sb.toString();
    }

    private String buildFromClause(List<PostgresTable> tables) {
        return tables.stream().map(PostgresTable::getName).collect(Collectors.joining(", "));
    }

    private PostgresExpression generateCompoundPredicate(PostgresExpressionGenerator gen) {
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        PostgresExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            PostgresExpression term = generateSafeScalarExpression(gen);
            if (Randomly.getBoolean()) {
                term = new PostgresPrefixOperation(term, PostgresPrefixOperation.PrefixOperator.NOT);
            }
            if (predicate == null) {
                predicate = term;
            } else {
                PostgresBinaryLogicalOperation.BinaryLogicalOperator op = Randomly
                        .fromOptions(PostgresBinaryLogicalOperation.BinaryLogicalOperator.AND,
                                PostgresBinaryLogicalOperation.BinaryLogicalOperator.OR);
                predicate = new PostgresBinaryLogicalOperation(predicate, term, op);
            }
        }
        return predicate == null ? generateSafeScalarExpression(gen) : predicate;
    }

    private PostgresExpression generateSafeScalarExpression(PostgresExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            PostgresExpression expr = gen.generateExpression(PostgresDataType.BOOLEAN);
            if (isSafeScalar(expr)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    /**
     * Generate a HAVING predicate that is safe to relocate (no subqueries, joins, window
     * functions, etc.) but is allowed to contain aggregate functions. Aggregates are the
     * whole point of HAVING - rejecting them would defeat the test.
     */
    private PostgresExpression generateSafeScalarHavingExpression(PostgresExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            PostgresExpression expr = gen.generateExpression(PostgresDataType.BOOLEAN);
            if (isSafeForHaving(expr)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private boolean isSafeScalar(PostgresExpression expr) {
        return checkSafe(expr, false);
    }

    private boolean isSafeForHaving(PostgresExpression expr) {
        return checkSafe(expr, true);
    }

    private boolean checkSafe(PostgresExpression expr, boolean allowAggregates) {
        if (expr == null) {
            return false;
        }
        if (expr instanceof PostgresAggregate) {
            if (!allowAggregates) {
                return false;
            }
            for (PostgresExpression arg : ((PostgresAggregate) expr).getArgs()) {
                if (!checkSafe(arg, allowAggregates)) {
                    return false;
                }
            }
            return true;
        }
        if (expr instanceof PostgresConstant || expr instanceof PostgresColumnReference
                || expr instanceof PostgresColumnValue) {
            return true;
        }
        if (expr instanceof PostgresPrefixOperation) {
            return checkSafe(((PostgresPrefixOperation) expr).getExpression(), allowAggregates);
        }
        if (expr instanceof PostgresPostfixOperation) {
            return checkSafe(((PostgresPostfixOperation) expr).getExpression(), allowAggregates);
        }
        if (expr instanceof PostgresBinaryLogicalOperation) {
            PostgresBinaryLogicalOperation op = (PostgresBinaryLogicalOperation) expr;
            return checkSafe(op.getLeft(), allowAggregates) && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresBinaryComparisonOperation) {
            PostgresBinaryComparisonOperation op = (PostgresBinaryComparisonOperation) expr;
            return checkSafe(op.getLeft(), allowAggregates) && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresBinaryArithmeticOperation) {
            PostgresBinaryArithmeticOperation op = (PostgresBinaryArithmeticOperation) expr;
            return checkSafe(op.getLeft(), allowAggregates) && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresBinaryBitOperation) {
            PostgresBinaryBitOperation op = (PostgresBinaryBitOperation) expr;
            return checkSafe(op.getLeft(), allowAggregates) && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresBinaryRangeOperation) {
            PostgresBinaryRangeOperation op = (PostgresBinaryRangeOperation) expr;
            return checkSafe(op.getLeft(), allowAggregates) && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresInOperation) {
            PostgresInOperation op = (PostgresInOperation) expr;
            if (!checkSafe(op.getExpr(), allowAggregates)) {
                return false;
            }
            for (PostgresExpression e : op.getListElements()) {
                if (!checkSafe(e, allowAggregates)) {
                    return false;
                }
            }
            return true;
        }
        if (expr instanceof PostgresBetweenOperation) {
            PostgresBetweenOperation op = (PostgresBetweenOperation) expr;
            return checkSafe(op.getExpr(), allowAggregates) && checkSafe(op.getLeft(), allowAggregates)
                    && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresLikeOperation) {
            PostgresLikeOperation op = (PostgresLikeOperation) expr;
            return checkSafe(op.getLeft(), allowAggregates) && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresSimilarTo) {
            PostgresSimilarTo op = (PostgresSimilarTo) expr;
            return checkSafe(op.getString(), allowAggregates) && checkSafe(op.getSimilarTo(), allowAggregates)
                    && (op.getEscapeCharacter() == null || checkSafe(op.getEscapeCharacter(), allowAggregates));
        }
        if (expr instanceof PostgresPOSIXRegularExpression) {
            PostgresPOSIXRegularExpression op = (PostgresPOSIXRegularExpression) expr;
            return checkSafe(op.getString(), allowAggregates) && checkSafe(op.getRegex(), allowAggregates);
        }
        if (expr instanceof PostgresFunction) {
            PostgresFunction func = (PostgresFunction) expr;
            for (PostgresExpression e : func.getArguments()) {
                if (!checkSafe(e, allowAggregates)) {
                    return false;
                }
            }
            return true;
        }
        if (expr instanceof PostgresConcatOperation) {
            PostgresConcatOperation op = (PostgresConcatOperation) expr;
            return checkSafe(op.getLeft(), allowAggregates) && checkSafe(op.getRight(), allowAggregates);
        }
        if (expr instanceof PostgresCollate) {
            return checkSafe(((PostgresCollate) expr).getExpr(), allowAggregates);
        }
        if (expr instanceof PostgresPostfixText) {
            return checkSafe(((PostgresPostfixText) expr).getExpr(), allowAggregates);
        }
        if (expr instanceof PostgresCastOperation) {
            return checkSafe(((PostgresCastOperation) expr).getExpression(), allowAggregates);
        }
        // Reject anything that introduces a new scope/correlated semantics:
        // subqueries, joins, table refs, ORDER BY terms, window functions.
        if (expr instanceof PostgresSelect || expr instanceof PostgresJoin
                || expr instanceof PostgresTableReference || expr instanceof PostgresOrderByTerm
                || expr instanceof PostgresWindowFunction) {
            return false;
        }
        return false;
    }
}
