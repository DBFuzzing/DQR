package sqlancer.duckdb.test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import sqlancer.ComparatorHelper;
import sqlancer.IgnoreMeException;
import sqlancer.Randomly;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;
import sqlancer.duckdb.DuckDBErrors;
import sqlancer.duckdb.DuckDBProvider.DuckDBGlobalState;
import sqlancer.duckdb.DuckDBSchema.DuckDBColumn;
import sqlancer.duckdb.DuckDBSchema.DuckDBTable;
import sqlancer.duckdb.DuckDBSchema.DuckDBTables;
import sqlancer.duckdb.DuckDBToStringVisitor;
import sqlancer.duckdb.ast.DuckDBBinaryOperator;
import sqlancer.duckdb.ast.DuckDBColumnReference;
import sqlancer.duckdb.ast.DuckDBConstant;
import sqlancer.duckdb.ast.DuckDBExpression;
import sqlancer.duckdb.ast.DuckDBFunction;
import sqlancer.duckdb.ast.DuckDBJoin;
import sqlancer.duckdb.ast.DuckDBOrderingTerm;
import sqlancer.duckdb.ast.DuckDBPostFixText;
import sqlancer.duckdb.ast.DuckDBSelect;
import sqlancer.duckdb.ast.DuckDBTableReference;
import sqlancer.duckdb.ast.DuckDBUnaryPrefixOperator;
import sqlancer.duckdb.gen.DuckDBExpressionGenerator;

public class DuckDBTimeEquivalenceOracle implements TestOracle<DuckDBGlobalState> {

    private enum Rule {
        WHERE_TO_SUBQUERY, EXISTS_TO_SUBQUERY, HAVING_TO_SUBQUERY
    }

    private static final String[] AGGREGATE_FUNCTIONS = { "COUNT", "SUM", "MIN", "MAX", "AVG" };
    private static final String[] COMPARISON_OPERATORS = { "=", "!=", "<", "<=", ">", ">=" };

    private final DuckDBGlobalState state;
    private final ExpectedErrors errors = new ExpectedErrors();

    public DuckDBTimeEquivalenceOracle(DuckDBGlobalState state) {
        this.state = state;
        DuckDBErrors.addExpressionErrors(errors);
        DuckDBErrors.addGroupByErrors(errors);
        errors.add("Binder Error");
        errors.add("Conversion Error");
        errors.add("Out of Range Error");
        errors.add("overflow");
        errors.add("division by zero");
        errors.add("Could not choose a best candidate function");
        errors.add("must appear in the GROUP BY clause");
        errors.add("aggregate function");
        errors.add("Catalog Error");
        errors.add("CONCAT");
        errors.add("Scalar Function with name to_json does not exist");
        errors.add("quantile");
        errors.add("STRING_AGG");
        errors.add("not an aggregate");
    }

    @Override
    public void check() throws SQLException {
        DuckDBTables tables = state.getSchema().getRandomTableNonEmptyTables();
        List<DuckDBTable> tableList = tables.getTables();
        if (tableList.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<DuckDBColumn> columns = tables.getColumns();
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        DuckDBExpressionGenerator gen = new DuckDBExpressionGenerator(state).setColumns(columns);

        Rule rule = Randomly.fromOptions(Rule.values());
        switch (rule) {
            case WHERE_TO_SUBQUERY:
                checkWhereToSubquery(gen, tableList, columns);
                break;
            case EXISTS_TO_SUBQUERY:
                checkExistsToSubquery(tableList);
                break;
            case HAVING_TO_SUBQUERY:
                checkHavingToSubquery(tableList, columns);
                break;
            default:
                throw new AssertionError(rule);
        }
    }

    // ==================== WHERE_TO_SUBQUERY ====================

    private void checkWhereToSubquery(DuckDBExpressionGenerator gen, List<DuckDBTable> tables,
            List<DuckDBColumn> columns) throws SQLException {
        DuckDBExpression predicate = generateCompoundPredicate(gen);
        String predicateString = DuckDBToStringVisitor.asString(predicate);
        String signatureExpr = buildSignatureExpression(columns, gen, false);
        String fromClause = buildFromClauseWithOptionalJoins(tables);
        String selectModifier = chooseSelectModifier();

        String baseQuery = "SELECT " + selectModifier + signatureExpr + " FROM " + fromClause + " WHERE "
                + predicateString;
        String innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + predicateString + ") AS ref1 FROM "
                + fromClause;
        String movedQuery = "WITH s AS MATERIALIZED (" + innerQuery + ") SELECT " + selectModifier
                + "ref0 FROM s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    // ==================== EXISTS_TO_SUBQUERY ====================

    private void checkExistsToSubquery(List<DuckDBTable> outerTables) throws SQLException {
        List<DuckDBColumn> outerColumns = outerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        if (outerColumns.isEmpty()) {
            throw new IgnoreMeException();
        }

        List<DuckDBTable> innerTables = Randomly.nonEmptySubset(state.getSchema().getDatabaseTables());
        List<DuckDBColumn> innerColumns = innerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        if (innerColumns.isEmpty()) {
            throw new IgnoreMeException();
        }
        DuckDBExpressionGenerator innerGen = new DuckDBExpressionGenerator(state).setColumns(innerColumns);
        DuckDBExpression innerPredicate = generateSafeScalarExpression(innerGen);

        String innerFrom = buildFromClauseWithOptionalJoins(innerTables);
        String innerPredicateString = DuckDBToStringVisitor.asString(innerPredicate);
        String existsString = "EXISTS (SELECT 1 FROM " + innerFrom + " WHERE " + innerPredicateString + ")";

        String signatureExpr = buildSignatureExpression(outerColumns,
                new DuckDBExpressionGenerator(state).setColumns(outerColumns), false);
        String outerFrom = buildFromClauseWithOptionalJoins(outerTables);
        String selectModifier = chooseSelectModifier();

        DuckDBExpression outerPredicate = Randomly.getBoolean()
                ? generateCompoundPredicate(new DuckDBExpressionGenerator(state).setColumns(outerColumns))
                : null;
        String outerPredicateString = null;
        if (outerPredicate != null) {
            outerPredicateString = DuckDBToStringVisitor.asString(outerPredicate);
        }

        String baseQuery;
        if (outerPredicate == null) {
            baseQuery = "SELECT " + selectModifier + signatureExpr + " FROM " + outerFrom + " WHERE " + existsString;
        } else {
            baseQuery = "SELECT " + selectModifier + signatureExpr + " FROM " + outerFrom + " WHERE (" + existsString
                    + ") AND (" + outerPredicateString + ")";
        }

        String innerQuery;
        if (outerPredicate == null) {
            innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + existsString + ") AS ref1 FROM " + outerFrom;
        } else {
            innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + existsString + ") AS ref1, ("
                    + outerPredicateString + ") AS ref2 FROM " + outerFrom;
        }

        String movedQuery;
        if (outerPredicate == null) {
            movedQuery = "WITH s AS MATERIALIZED (" + innerQuery + ") SELECT " + selectModifier
                    + "ref0 FROM s WHERE ref1";
        } else {
            movedQuery = "WITH s AS MATERIALIZED (" + innerQuery + ") SELECT " + selectModifier
                    + "ref0 FROM s WHERE ref1 AND ref2";
        }

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    // ==================== HAVING_TO_SUBQUERY ====================

    private void checkHavingToSubquery(List<DuckDBTable> tables, List<DuckDBColumn> columns) throws SQLException {
        List<DuckDBColumn> groupByColumns = Randomly.nonEmptySubset(columns);

        // Generate compound HAVING predicate with aggregates
        String havingString = generateAggregatePredicate(groupByColumns);

        // Optional WHERE clause (pre-aggregation filtering)
        DuckDBExpressionGenerator whereGen = new DuckDBExpressionGenerator(state).setColumns(columns);
        String whereClause = null;
        if (Randomly.getBoolean()) {
            DuckDBExpression wherePred = generateCompoundPredicate(whereGen);
            whereClause = DuckDBToStringVisitor.asString(wherePred);
        }

        // Signature uses GROUP BY columns, optionally with an aggregate
        String signatureExpr = buildSignatureExpression(groupByColumns,
                new DuckDBExpressionGenerator(state).setColumns(groupByColumns), true);
        String fromClause = buildFromClauseWithOptionalJoins(tables);
        String groupByClause = groupByColumns.stream().map(DuckDBColumn::getFullQualifiedName)
                .collect(Collectors.joining(", "));
        String selectModifier = chooseSelectModifier();

        String whereFragment = whereClause == null ? "" : " WHERE " + whereClause;

        String baseQuery = "SELECT " + selectModifier + signatureExpr + " FROM " + fromClause + whereFragment
                + " GROUP BY " + groupByClause + " HAVING " + havingString;

        String innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + havingString + ") AS ref1 FROM " + fromClause
                + whereFragment + " GROUP BY " + groupByClause;

        String movedQuery = "WITH s AS MATERIALIZED (" + innerQuery + ") SELECT " + selectModifier
                + "ref0 FROM s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    // ==================== Predicate Generation ====================

    /**
     * Generates a compound scalar predicate with 1-3 terms combined by AND/OR.
     */
    private DuckDBExpression generateCompoundPredicate(DuckDBExpressionGenerator gen) {
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        DuckDBExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            DuckDBExpression term = generateSafeScalarExpression(gen);
            if (Randomly.getBoolean()) {
                term = new DuckDBUnaryPrefixOperator(term,
                        DuckDBExpressionGenerator.DuckDBUnaryPrefixOperator.NOT);
            }
            if (Randomly.getBooleanWithSmallProbability()) {
                term = new DuckDBPostFixText(term,
                        Randomly.fromOptions(" IS TRUE", " IS FALSE", " IS NULL", " IS NOT NULL"));
            }
            if (predicate == null) {
                predicate = term;
            } else {
                DuckDBExpressionGenerator.DuckDBBinaryLogicalOperator op = Randomly.fromOptions(
                        DuckDBExpressionGenerator.DuckDBBinaryLogicalOperator.AND,
                        DuckDBExpressionGenerator.DuckDBBinaryLogicalOperator.OR);
                predicate = new DuckDBBinaryOperator(predicate, term, op);
            }
        }
        return predicate == null ? generateSafeScalarExpression(gen) : predicate;
    }

    /**
     * Generates a compound HAVING predicate with 1-3 aggregate comparison terms.
     * e.g., "COUNT(*) > 3 AND SUM(t0.c1) <= 100"
     */
    private String generateAggregatePredicate(List<DuckDBColumn> groupByColumns) {
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < terms; i++) {
            if (i > 0) {
                sb.append(Randomly.fromOptions(" AND ", " OR "));
            }
            sb.append(generateSingleAggregateComparison(groupByColumns));
        }
        return sb.toString();
    }

    /**
     * Generates a single aggregate comparison like "COUNT(*) > 3" or "SUM(col) <= 100".
     */
    private String generateSingleAggregateComparison(List<DuckDBColumn> groupByColumns) {
        String aggFunc = Randomly.fromOptions(AGGREGATE_FUNCTIONS);
        String compOp = Randomly.fromOptions(COMPARISON_OPERATORS);

        String aggExpr;
        if ("COUNT".equals(aggFunc) && Randomly.getBoolean()) {
            aggExpr = "COUNT(*)";
        } else {
            DuckDBColumn col = Randomly.fromList(groupByColumns);
            aggExpr = aggFunc + "(" + col.getFullQualifiedName() + ")";
        }

        long constant = state.getRandomly().getInteger();
        String result = aggExpr + " " + compOp + " " + constant;

        // Optionally negate
        if (Randomly.getBooleanWithSmallProbability()) {
            result = "NOT (" + result + ")";
        }

        return "(" + result + ")";
    }

    /**
     * Generates a safe scalar expression by retrying until one passes the blacklist check.
     */
    private DuckDBExpression generateSafeScalarExpression(DuckDBExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            DuckDBExpression expr = gen.generateExpression();
            if (isSafeScalar(expr)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    // ==================== Signature Expression ====================

    /**
     * Builds a CONCAT-based signature expression for comparing query results.
     * Uses to_json() for type-preserving serialization.
     * When includeAggregate is true, may add an aggregate expression (for HAVING queries).
     */
    private String buildSignatureExpression(List<DuckDBColumn> columns, DuckDBExpressionGenerator gen,
            boolean includeAggregate) {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("CONCAT(");
        int parts = 0;
        for (int i = 0; i < columns.size(); i++) {
            DuckDBColumn col = columns.get(i);
            if (parts > 0) {
                sb.append(", '#', ");
            }
            sb.append("COALESCE(to_json(");
            sb.append(col.getFullQualifiedName());
            sb.append("), 'null')");
            parts++;
        }
        // Optionally add a random safe scalar expression
        if (gen != null && Randomly.getBoolean()) {
            DuckDBExpression extra = generateSafeScalarExpression(gen);
            sb.append(", '#', ");
            sb.append("COALESCE(to_json(");
            sb.append(DuckDBToStringVisitor.asString(extra));
            sb.append("), 'null')");
        }
        // Optionally add an aggregate expression for HAVING queries
        if (includeAggregate && Randomly.getBoolean()) {
            String aggFunc = Randomly.fromOptions("COUNT", "SUM", "MIN", "MAX");
            String aggExpr;
            if ("COUNT".equals(aggFunc) && Randomly.getBoolean()) {
                aggExpr = "COUNT(*)";
            } else {
                DuckDBColumn col = Randomly.fromList(columns);
                aggExpr = aggFunc + "(" + col.getFullQualifiedName() + ")";
            }
            sb.append(", '#', ");
            sb.append("COALESCE(CAST(");
            sb.append(aggExpr);
            sb.append(" AS VARCHAR), 'null')");
        }
        sb.append(")");
        return sb.toString();
    }

    // ==================== FROM Clause with Optional JOINs ====================

    /**
     * Builds a FROM clause, optionally adding JOIN clauses when multiple tables are available.
     */
    private String buildFromClauseWithOptionalJoins(List<DuckDBTable> tables) {
        if (tables.size() >= 2 && Randomly.getBoolean()) {
            // Generate JOINs
            List<DuckDBTableReference> tableRefs = tables.stream().map(DuckDBTableReference::new)
                    .collect(Collectors.toList());
            List<DuckDBJoin> joins = generateJoins(tableRefs);
            return buildFromClause(tableRefs, joins);
        } else {
            // Simple comma-separated FROM
            return tables.stream().map(DuckDBTable::getName).collect(Collectors.joining(", "));
        }
    }

    /**
     * Generates random INNER/LEFT/RIGHT JOINs from available table references.
     */
    private List<DuckDBJoin> generateJoins(List<DuckDBTableReference> tableList) {
        List<DuckDBJoin> joinExpressions = new ArrayList<>();
        while (tableList.size() >= 2 && (joinExpressions.isEmpty() || Randomly.getBooleanWithRatherLowProbability())) {
            DuckDBTableReference leftTable = tableList.remove(0);
            DuckDBTableReference rightTable = tableList.remove(0);
            List<DuckDBColumn> joinColumns = new ArrayList<>(leftTable.getTable().getColumns());
            joinColumns.addAll(rightTable.getTable().getColumns());
            DuckDBExpressionGenerator joinGen = new DuckDBExpressionGenerator(state).setColumns(joinColumns);
            DuckDBExpression joinPredicate = generateSafeScalarExpression(joinGen);
            DuckDBJoin.JoinType joinType = Randomly.fromOptions(DuckDBJoin.JoinType.INNER, DuckDBJoin.JoinType.LEFT,
                    DuckDBJoin.JoinType.RIGHT);
            switch (joinType) {
                case INNER:
                    joinExpressions.add(DuckDBJoin.createInnerJoin(leftTable, rightTable, joinPredicate));
                    break;
                case LEFT:
                    joinExpressions.add(DuckDBJoin.createLeftOuterJoin(leftTable, rightTable, joinPredicate));
                    break;
                case RIGHT:
                    joinExpressions.add(DuckDBJoin.createRightOuterJoin(leftTable, rightTable, joinPredicate));
                    break;
                default:
                    throw new AssertionError(joinType);
            }
        }
        return joinExpressions;
    }

    private String buildFromClause(List<DuckDBTableReference> tableList, List<DuckDBJoin> joins) {
        String fromPart = tableList.stream().map(t -> t.getTable().getName()).collect(Collectors.joining(", "));
        String joinPart = joins.stream().map(DuckDBToStringVisitor::asString).collect(Collectors.joining(" "));
        if (!fromPart.isEmpty() && !joinPart.isEmpty()) {
            return fromPart + " " + joinPart;
        }
        return !fromPart.isEmpty() ? fromPart : joinPart;
    }

    // ==================== SELECT modifier (DISTINCT) ====================

    private String chooseSelectModifier() {
        return Randomly.getBoolean() ? "" : "DISTINCT ";
    }

    // ==================== Safety Check (Blacklist-based) ====================

    /**
     * Returns true if the expression is safe for use in the oracle (no forbidden sub-expressions).
     * Uses a BLACKLIST approach: only rejects known-dangerous patterns, accepts everything else.
     */
    private boolean isSafeScalar(DuckDBExpression expr) {
        return expr != null && !containsForbiddenExpression(expr);
    }

    /**
     * Recursively checks for forbidden sub-expressions.
     * Forbidden: subqueries (DuckDBSelect), JOINs, table references, ORDER BY terms,
     * and non-deterministic functions.
     */
    private boolean containsForbiddenExpression(DuckDBExpression expr) {
        if (expr == null) {
            return false;
        }
        // Structural nodes that cannot appear in a scalar predicate
        if (expr instanceof DuckDBSelect || expr instanceof DuckDBJoin
                || expr instanceof DuckDBTableReference || expr instanceof DuckDBOrderingTerm) {
            return true;
        }
        // Check functions for non-determinism
        if (expr instanceof DuckDBFunction) {
            DuckDBFunction<?> func = (DuckDBFunction<?>) expr;
            if (isNonDeterministicFunction(func.getFunc().toString())) {
                return true;
            }
            for (DuckDBExpression e : func.getArgs()) {
                if (containsForbiddenExpression(e)) {
                    return true;
                }
            }
            return false;
        }
        // Recursively check all sub-expressions using visitor pattern
        if (expr instanceof DuckDBUnaryPrefixOperator) {
            return containsForbiddenExpression(((DuckDBUnaryPrefixOperator) expr).getExpr());
        }
        if (expr instanceof sqlancer.duckdb.ast.DuckDBUnaryPostfixOperator) {
            return containsForbiddenExpression(
                    ((sqlancer.duckdb.ast.DuckDBUnaryPostfixOperator) expr).getExpr());
        }
        if (expr instanceof DuckDBBinaryOperator) {
            DuckDBBinaryOperator op = (DuckDBBinaryOperator) expr;
            return containsForbiddenExpression(op.getLeft()) || containsForbiddenExpression(op.getRight());
        }
        if (expr instanceof sqlancer.duckdb.ast.DuckDBBetweenOperator) {
            sqlancer.duckdb.ast.DuckDBBetweenOperator op = (sqlancer.duckdb.ast.DuckDBBetweenOperator) expr;
            return containsForbiddenExpression(op.getLeft()) || containsForbiddenExpression(op.getMiddle())
                    || containsForbiddenExpression(op.getRight());
        }
        if (expr instanceof sqlancer.duckdb.ast.DuckDBCaseOperator) {
            sqlancer.duckdb.ast.DuckDBCaseOperator op = (sqlancer.duckdb.ast.DuckDBCaseOperator) expr;
            if (op.getSwitchCondition() != null && containsForbiddenExpression(op.getSwitchCondition())) {
                return true;
            }
            for (DuckDBExpression e : op.getConditions()) {
                if (containsForbiddenExpression(e)) {
                    return true;
                }
            }
            for (DuckDBExpression e : op.getExpressions()) {
                if (containsForbiddenExpression(e)) {
                    return true;
                }
            }
            return op.getElseExpr() != null && containsForbiddenExpression(op.getElseExpr());
        }
        if (expr instanceof sqlancer.duckdb.ast.DuckDBInOperator) {
            sqlancer.duckdb.ast.DuckDBInOperator op = (sqlancer.duckdb.ast.DuckDBInOperator) expr;
            if (containsForbiddenExpression(op.getLeft())) {
                return true;
            }
            for (DuckDBExpression e : op.getRight()) {
                if (containsForbiddenExpression(e)) {
                    return true;
                }
            }
            return false;
        }
        if (expr instanceof sqlancer.duckdb.ast.DuckDBTernary) {
            sqlancer.duckdb.ast.DuckDBTernary op = (sqlancer.duckdb.ast.DuckDBTernary) expr;
            return containsForbiddenExpression(op.getLeft()) || containsForbiddenExpression(op.getMiddle())
                    || containsForbiddenExpression(op.getRight());
        }
        if (expr instanceof DuckDBPostFixText) {
            return containsForbiddenExpression(((DuckDBPostFixText) expr).getExpr());
        }
        // NewUnaryPostfixOperatorNode (covers DuckDBCastOperation and similar)
        if (expr instanceof sqlancer.common.ast.newast.NewUnaryPostfixOperatorNode) {
            @SuppressWarnings("unchecked")
            sqlancer.common.ast.newast.NewUnaryPostfixOperatorNode<DuckDBExpression> node = (sqlancer.common.ast.newast.NewUnaryPostfixOperatorNode<DuckDBExpression>) expr;
            return containsForbiddenExpression(node.getExpr());
        }
        // Constants and column references are always safe
        if (expr instanceof DuckDBConstant || expr instanceof DuckDBColumnReference) {
            return false;
        }
        // Default: accept unknown expressions (blacklist approach)
        return false;
    }

    /**
     * Checks if a function name is non-deterministic and should be excluded.
     */
    private boolean isNonDeterministicFunction(String name) {
        if (name == null) {
            return false;
        }
        String normalized = name.trim().toUpperCase();
        switch (normalized) {
            case "RANDOM":
            case "SETSEED":
            case "UUID":
            case "GEN_RANDOM_UUID":
            case "NOW":
            case "CURRENT_DATE":
            case "CURRENT_TIME":
            case "CURRENT_TIMESTAMP":
            case "TODAY":
            case "TIMEOFDAY":
            case "TRANSACTION_TIMESTAMP":
            case "CLOCK_TIMESTAMP":
            case "STATEMENT_TIMESTAMP":
                return true;
            default:
                return false;
        }
    }
}
