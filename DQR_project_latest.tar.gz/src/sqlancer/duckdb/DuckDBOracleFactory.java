package sqlancer.duckdb;

import java.sql.SQLException;

import sqlancer.OracleFactory;
import sqlancer.common.oracle.NoRECOracle;
import sqlancer.common.oracle.TLPWhereOracle;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;
import sqlancer.duckdb.gen.DuckDBExpressionGenerator;
import sqlancer.duckdb.test.DuckDBTimeEquivalenceOracle;


public enum DuckDBOracleFactory implements OracleFactory<DuckDBProvider.DuckDBGlobalState> {
    NOREC {
        @Override
        public TestOracle<DuckDBProvider.DuckDBGlobalState> create(DuckDBProvider.DuckDBGlobalState globalState)
                throws SQLException {
            DuckDBExpressionGenerator gen = new DuckDBExpressionGenerator(globalState);
            ExpectedErrors errors = ExpectedErrors.newErrors().with(DuckDBErrors.getExpressionErrors())
                    .withRegex(DuckDBErrors.getExpressionErrorsRegex())
                    .with("canceling statement due to statement timeout").build();
            return new NoRECOracle<>(globalState, gen, errors);
        }

    },
    WHERE {
        @Override
        public TestOracle<DuckDBProvider.DuckDBGlobalState> create(DuckDBProvider.DuckDBGlobalState globalState)
                throws SQLException {
            DuckDBExpressionGenerator gen = new DuckDBExpressionGenerator(globalState);
            ExpectedErrors expectedErrors = ExpectedErrors.newErrors().with(DuckDBErrors.getExpressionErrors())
                    .with(DuckDBErrors.getGroupByErrors()).withRegex(DuckDBErrors.getExpressionErrorsRegex()).build();

            return new TLPWhereOracle<>(globalState, gen, expectedErrors);
        }
    },
    TIME_EQUIV {
        @Override
        public TestOracle<DuckDBProvider.DuckDBGlobalState> create(DuckDBProvider.DuckDBGlobalState globalState)
                throws SQLException {
            return new DuckDBTimeEquivalenceOracle(globalState);
        }
    };

}
