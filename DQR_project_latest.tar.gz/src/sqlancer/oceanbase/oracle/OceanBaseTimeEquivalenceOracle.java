package sqlancer.oceanbase.oracle;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import sqlancer.ComparatorHelper;
import sqlancer.IgnoreMeException;
import sqlancer.Randomly;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;
import sqlancer.oceanbase.OceanBaseErrors;
import sqlancer.oceanbase.OceanBaseGlobalState;
import sqlancer.oceanbase.OceanBaseSchema.OceanBaseColumn;
import sqlancer.oceanbase.OceanBaseSchema.OceanBaseTable;
import sqlancer.oceanbase.OceanBaseSchema.OceanBaseTables;
import sqlancer.oceanbase.OceanBaseVisitor;
import sqlancer.oceanbase.ast.OceanBaseAggregate;
import sqlancer.oceanbase.ast.OceanBaseAggregate.OceanBaseAggregateFunction;
import sqlancer.oceanbase.ast.OceanBaseBinaryComparisonOperation;
import sqlancer.oceanbase.ast.OceanBaseBinaryComparisonOperation.BinaryComparisonOperator;
import sqlancer.oceanbase.ast.OceanBaseBinaryLogicalOperation;
import sqlancer.oceanbase.ast.OceanBaseCastOperation;
import sqlancer.oceanbase.ast.OceanBaseColumnName;
import sqlancer.oceanbase.ast.OceanBaseColumnReference;
import sqlancer.oceanbase.ast.OceanBaseComputableFunction;
import sqlancer.oceanbase.ast.OceanBaseConstant;
import sqlancer.oceanbase.ast.OceanBaseExists;
import sqlancer.oceanbase.ast.OceanBaseExpression;
import sqlancer.oceanbase.ast.OceanBaseInOperation;
import sqlancer.oceanbase.ast.OceanBaseJoin;
import sqlancer.oceanbase.ast.OceanBaseOrderByTerm;
import sqlancer.oceanbase.ast.OceanBaseSelect;
import sqlancer.oceanbase.ast.OceanBaseStringExpression;
import sqlancer.oceanbase.ast.OceanBaseTableReference;
import sqlancer.oceanbase.ast.OceanBaseText;
import sqlancer.oceanbase.ast.OceanBaseUnaryPostfixOperation;
import sqlancer.oceanbase.ast.OceanBaseUnaryPrefixOperation;
import sqlancer.oceanbase.ast.OceanBaseUnaryPrefixOperation.OceanBaseUnaryPrefixOperator;
import sqlancer.oceanbase.gen.OceanBaseExpressionGenerator;

public class OceanBaseTimeEquivalenceOracle implements TestOracle<OceanBaseGlobalState> {

    private enum Rule {
        WHERE_TO_SUBQUERY, EXISTS_TO_SUBQUERY, HAVING_TO_SUBQUERY
    }

    private final OceanBaseGlobalState state;
    private final ExpectedErrors errors = new ExpectedErrors();

    public OceanBaseTimeEquivalenceOracle(OceanBaseGlobalState state) {
        this.state = state;
        OceanBaseErrors.addExpressionErrors(errors);
        errors.addAllRegexes(OceanBaseErrors.getExpressionErrorsRegex());
        errors.add("value is out of range");
        // errors.add("Internal error");
    }

    @Override
    public void check() throws Exception {
        OceanBaseTables tables = state.getSchema().getRandomTableNonEmptyTables();
        List<OceanBaseTable> tableList = tables.getTables();
        if (tableList.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<OceanBaseColumn> columns = tables.getColumns();
        OceanBaseExpressionGenerator gen = new OceanBaseExpressionGenerator(state).setColumns(columns);

        switch (Randomly.fromOptions(Rule.values())) {
            case WHERE_TO_SUBQUERY:
                checkWhereToSubquery(gen, tableList, columns);
                break;
            case EXISTS_TO_SUBQUERY:
                checkExistsToSubquery(tableList);
                break;
            case HAVING_TO_SUBQUERY:
                checkHavingToSubquery(gen, tableList, columns);
                break;
            default:
                throw new AssertionError();
        }
    }

    private void checkWhereToSubquery(OceanBaseExpressionGenerator gen, List<OceanBaseTable> tables,
            List<OceanBaseColumn> columns) throws Exception {
        OceanBaseExpression predicate = generateCompoundPredicate(gen);
        OceanBaseExpression frozenPredicate = freeze(predicate);
        OceanBaseExpression signatureExpr = buildSignatureExpression(columns, gen);
        OceanBaseSelect.SelectType selectType = chooseSelectType();

        OceanBaseSelect base = new OceanBaseSelect();
        base.setSelectType(selectType);
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(tables.stream().map(OceanBaseTableReference::new).collect(Collectors.toList()));
        base.setWhereClause(frozenPredicate);

        OceanBaseSelect inner = new OceanBaseSelect();
        inner.setSelectType(OceanBaseSelect.SelectType.ALL);
        inner.setFetchColumns(
                List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(frozenPredicate, "ref1")));
        inner.setFromList(tables.stream().map(OceanBaseTableReference::new).collect(Collectors.toList()));

        String baseQuery = OceanBaseVisitor.asString(base);
        String innerQuery = OceanBaseVisitor.asString(inner);
        String movedQuery = "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery + ") AS s WHERE ref1";

        compareQueries(baseQuery, movedQuery);
    }

    private void checkExistsToSubquery(List<OceanBaseTable> outerTables) throws Exception {
        List<OceanBaseExpression> outerFrom = outerTables.stream().map(OceanBaseTableReference::new)
                .collect(Collectors.toList());
        List<OceanBaseColumn> outerColumns = outerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        if (outerColumns.isEmpty()) {
            throw new IgnoreMeException();
        }

        List<OceanBaseTable> innerTables = Randomly.nonEmptySubset(state.getSchema().getDatabaseTables());
        List<OceanBaseColumn> innerColumns = innerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        OceanBaseExpressionGenerator innerGen = new OceanBaseExpressionGenerator(state).setColumns(innerColumns);
        OceanBaseExpression innerPredicate = generateCompoundPredicate(innerGen);

        OceanBaseSelect existsSubquery = new OceanBaseSelect();
        existsSubquery.setSelectType(OceanBaseSelect.SelectType.ALL);
        existsSubquery.setFetchColumns(List.of(aliasExpression(OceanBaseConstant.createIntConstant(1), "ref_exists")));
        existsSubquery.setFromList(innerTables.stream().map(OceanBaseTableReference::new).collect(Collectors.toList()));
        existsSubquery.setWhereClause(freeze(innerPredicate));

        OceanBaseExpression existsExpr = new OceanBaseExists(existsSubquery, OceanBaseConstant.createNullConstant());
        OceanBaseExpression frozenExists = freeze(existsExpr);
        OceanBaseExpression signatureExpr = buildSignatureExpression(outerColumns,
                new OceanBaseExpressionGenerator(state).setColumns(outerColumns));
        OceanBaseSelect.SelectType selectType = chooseSelectType();

        OceanBaseExpression outerPredicate = Randomly.getBoolean()
                ? generateCompoundPredicate(new OceanBaseExpressionGenerator(state).setColumns(outerColumns))
                : null;
        OceanBaseExpression frozenOuter = outerPredicate == null ? null : freeze(outerPredicate);

        OceanBaseSelect base = new OceanBaseSelect();
        base.setSelectType(selectType);
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(outerFrom);
        if (frozenOuter == null) {
            base.setWhereClause(frozenExists);
        } else {
            base.setWhereClause(new OceanBaseStringExpression(
                    "(" + OceanBaseVisitor.asString(frozenExists) + ") AND (" + OceanBaseVisitor.asString(frozenOuter)
                            + ")",
                    OceanBaseConstant.createNullConstant()));
        }

        OceanBaseSelect inner = new OceanBaseSelect();
        inner.setSelectType(OceanBaseSelect.SelectType.ALL);
        if (frozenOuter == null) {
            inner.setFetchColumns(
                    List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(frozenExists, "ref1")));
        } else {
            inner.setFetchColumns(List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(frozenExists, "ref1"),
                    aliasExpression(frozenOuter, "ref2")));
        }
        inner.setFromList(outerFrom);

        String baseQuery = OceanBaseVisitor.asString(base);
        String innerQuery = OceanBaseVisitor.asString(inner);
        String movedQuery = frozenOuter == null
                ? "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery + ") AS s WHERE ref1"
                : "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery + ") AS s WHERE ref1 AND ref2";

        compareQueries(baseQuery, movedQuery);
    }

    private void checkHavingToSubquery(OceanBaseExpressionGenerator gen, List<OceanBaseTable> tables,
            List<OceanBaseColumn> columns) throws Exception {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<OceanBaseColumn> groupByColumns = Randomly.nonEmptySubset(columns);
        OceanBaseExpression havingPredicate = generateHavingExpression(groupByColumns);
        OceanBaseExpression signatureExpr = buildSignatureExpression(groupByColumns,
                new OceanBaseExpressionGenerator(state).setColumns(groupByColumns));
        OceanBaseSelect.SelectType selectType = chooseSelectType();

        OceanBaseExpression wherePredicate = Randomly.getBoolean() ? generateCompoundPredicate(gen) : null;
        String signatureString = OceanBaseVisitor.asString(signatureExpr);
        String havingString = OceanBaseVisitor.asString(havingPredicate);
        String whereString = wherePredicate == null ? null : OceanBaseVisitor.asString(wherePredicate);
        String fromClause = tables.stream().map(t -> OceanBaseVisitor.asString(new OceanBaseTableReference(t)))
                .collect(Collectors.joining(", "));
        String groupByClause = groupByColumns.stream().map(OceanBaseColumn::getFullQualifiedName)
                .collect(Collectors.joining(", "));

        List<String> selectItems = new ArrayList<>();
        selectItems.add(signatureString + " AS sig");
        String havingStringWithAliases = havingString;
        for (int i = 0; i < groupByColumns.size(); i++) {
            OceanBaseColumn col = groupByColumns.get(i);
            String alias = "g" + i;
            selectItems.add(col.getFullQualifiedName() + " AS " + alias);
            havingStringWithAliases = havingStringWithAliases.replace(col.getFullQualifiedName(), alias);
        }

        String baseQuery = "SELECT " + selectTypeToSql(selectType) + " " + String.join(", ", selectItems) + " FROM "
                + fromClause + (whereString == null ? "" : " WHERE " + whereString) + " GROUP BY " + groupByClause
                + " HAVING " + havingStringWithAliases;
        String innerQuery = "SELECT " + signatureString + " AS ref0, (" + havingString + ") AS ref1 FROM "
                + fromClause + (whereString == null ? "" : " WHERE " + whereString) + " GROUP BY " + groupByClause;
        String movedQuery = "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery + ") AS s WHERE ref1";

        compareQueries(baseQuery, movedQuery);
    }

    private void compareQueries(String baseQuery, String movedQuery) throws Exception {
        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private OceanBaseExpression buildSignatureExpression(List<OceanBaseColumn> columns,
            OceanBaseExpressionGenerator gen) {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("CONCAT(");
        int parts = 0;
        for (OceanBaseColumn col : columns) {
            if (parts > 0) {
                sb.append(", '#', ");
            }
            sb.append("IFNULL(");
            sb.append(col.getFullQualifiedName());
            sb.append(", '__NULL__')");
            parts++;
        }
        if (gen != null && Randomly.getBoolean()) {
            OceanBaseExpression extra = generateSafeScalarExpression(gen);
            sb.append(", '#', ");
            sb.append("IFNULL(");
            sb.append(OceanBaseVisitor.asString(extra));
            sb.append(", '__NULL__')");
        }
        sb.append(")");
        return new OceanBaseStringExpression(sb.toString(), OceanBaseConstant.createNullConstant());
    }

    private OceanBaseExpression aliasExpression(OceanBaseExpression expr, String alias) {
        return new OceanBaseText(expr, " AS " + alias, false);
    }

    private OceanBaseExpression freeze(OceanBaseExpression expr) {
        return new OceanBaseStringExpression(OceanBaseVisitor.asString(expr), OceanBaseConstant.createNullConstant());
    }

    private OceanBaseSelect.SelectType chooseSelectType() {
        return Randomly.fromOptions(OceanBaseSelect.SelectType.values());
    }

    private String selectTypeToSql(OceanBaseSelect.SelectType selectType) {
        switch (selectType) {
            case DISTINCT:
                return "DISTINCT";
            case ALL:
                return "ALL";
            default:
                throw new AssertionError(selectType);
        }
    }

    private OceanBaseExpression generateCompoundPredicate(OceanBaseExpressionGenerator gen) {
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        OceanBaseExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            OceanBaseExpression term = generateSafeScalarExpression(gen);
            if (Randomly.getBoolean()) {
                term = new OceanBaseUnaryPrefixOperation(term, OceanBaseUnaryPrefixOperator.NOT);
            }
            if (predicate == null) {
                predicate = term;
            } else {
                OceanBaseBinaryLogicalOperation.OceanBaseBinaryLogicalOperator op = Randomly
                        .fromOptions(OceanBaseBinaryLogicalOperation.OceanBaseBinaryLogicalOperator.AND,
                                OceanBaseBinaryLogicalOperation.OceanBaseBinaryLogicalOperator.OR);
                predicate = new OceanBaseBinaryLogicalOperation(predicate, term, op);
            }
        }
        return predicate == null ? generateSafeScalarExpression(gen) : predicate;
    }

    private OceanBaseExpression generateSafeScalarExpression(OceanBaseExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            OceanBaseExpression expr = gen.generateExpression();
            if (isSafeScalar(expr, false)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private OceanBaseExpression generateSafeScalarExpressionAllowAggregate(OceanBaseExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            OceanBaseExpression expr = gen.generateExpression();
            if (isSafeScalar(expr, true)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private OceanBaseExpression generateHavingExpression(List<OceanBaseColumn> groupByColumns) {
        OceanBaseColumn col = Randomly.fromList(groupByColumns);
        OceanBaseAggregate agg = new OceanBaseAggregate(new OceanBaseColumnReference(col, null),
                OceanBaseAggregateFunction.COUNT);
        OceanBaseExpression right = OceanBaseConstant.createIntConstant(Randomly.getNotCachedInteger(0, 4));
        OceanBaseExpression predicate = new OceanBaseBinaryComparisonOperation(agg, right,
                Randomly.fromOptions(BinaryComparisonOperator.NOT_EQUALS, BinaryComparisonOperator.LESS,
                        BinaryComparisonOperator.GREATER, BinaryComparisonOperator.GREATER_EQUALS));
        if (Randomly.getBoolean()) {
            OceanBaseExpressionGenerator groupByGen = new OceanBaseExpressionGenerator(state)
                    .setColumns(groupByColumns);
            OceanBaseExpression extra = generateSafeScalarExpressionAllowAggregate(groupByGen);
            OceanBaseBinaryLogicalOperation.OceanBaseBinaryLogicalOperator op = Randomly
                    .fromOptions(OceanBaseBinaryLogicalOperation.OceanBaseBinaryLogicalOperator.AND,
                            OceanBaseBinaryLogicalOperation.OceanBaseBinaryLogicalOperator.OR);
            predicate = new OceanBaseBinaryLogicalOperation(predicate, extra, op);
        }
        return predicate;
    }

    private boolean isSafeScalar(OceanBaseExpression expr, boolean allowAggregate) {
        return expr != null && !containsForbiddenExpression(expr, allowAggregate);
    }

    private boolean containsForbiddenExpression(OceanBaseExpression expr, boolean allowAggregate) {
        if (expr == null) {
            return false;
        }
        if (expr instanceof OceanBaseConstant || expr instanceof OceanBaseColumnReference
                || expr instanceof OceanBaseColumnName) {
            return false;
        }
        if (expr instanceof OceanBaseAggregate) {
            return !allowAggregate || containsForbiddenExpression(((OceanBaseAggregate) expr).getExpr(), true);
        }
        if (expr instanceof OceanBaseUnaryPrefixOperation) {
            return containsForbiddenExpression(((OceanBaseUnaryPrefixOperation) expr).getExpr(), allowAggregate);
        }
        if (expr instanceof OceanBaseUnaryPostfixOperation) {
            return containsForbiddenExpression(((OceanBaseUnaryPostfixOperation) expr).getExpression(), allowAggregate);
        }
        if (expr instanceof OceanBaseBinaryLogicalOperation) {
            OceanBaseBinaryLogicalOperation op = (OceanBaseBinaryLogicalOperation) expr;
            return containsForbiddenExpression(op.getLeft(), allowAggregate)
                    || containsForbiddenExpression(op.getRight(), allowAggregate);
        }
        if (expr instanceof OceanBaseBinaryComparisonOperation) {
            OceanBaseBinaryComparisonOperation op = (OceanBaseBinaryComparisonOperation) expr;
            return containsForbiddenExpression(op.getLeft(), allowAggregate)
                    || containsForbiddenExpression(op.getRight(), allowAggregate);
        }
        if (expr instanceof OceanBaseCastOperation) {
            return containsForbiddenExpression(((OceanBaseCastOperation) expr).getExpr(), allowAggregate);
        }
        if (expr instanceof OceanBaseInOperation) {
            OceanBaseInOperation op = (OceanBaseInOperation) expr;
            if (containsForbiddenExpression(op.getExpr(), allowAggregate)) {
                return true;
            }
            for (OceanBaseExpression element : op.getListElements()) {
                if (containsForbiddenExpression(element, allowAggregate)) {
                    return true;
                }
            }
            return false;
        }
        if (expr instanceof OceanBaseComputableFunction) {
            for (OceanBaseExpression arg : ((OceanBaseComputableFunction) expr).getArguments()) {
                if (containsForbiddenExpression(arg, allowAggregate)) {
                    return true;
                }
            }
            return false;
        }
        return expr instanceof OceanBaseExists || expr instanceof OceanBaseSelect || expr instanceof OceanBaseJoin
                || expr instanceof OceanBaseOrderByTerm || expr instanceof OceanBaseText
                || expr instanceof OceanBaseStringExpression;
    }
}
