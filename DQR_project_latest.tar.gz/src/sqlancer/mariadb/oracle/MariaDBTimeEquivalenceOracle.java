package sqlancer.mariadb.oracle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import sqlancer.ComparatorHelper;
import sqlancer.IgnoreMeException;
import sqlancer.Randomly;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;
import sqlancer.mariadb.MariaDBErrors;
import sqlancer.mariadb.MariaDBProvider.MariaDBGlobalState;
import sqlancer.mariadb.MariaDBSchema.MariaDBColumn;
import sqlancer.mariadb.MariaDBSchema.MariaDBTable;
import sqlancer.mariadb.MariaDBSchema.MariaDBTables;
import sqlancer.mariadb.ast.MariaDBAggregate;
import sqlancer.mariadb.ast.MariaDBAggregate.MariaDBAggregateFunction;
import sqlancer.mariadb.ast.MariaDBBinaryOperator;
import sqlancer.mariadb.ast.MariaDBBinaryOperator.MariaDBBinaryComparisonOperator;
import sqlancer.mariadb.ast.MariaDBColumnName;
import sqlancer.mariadb.ast.MariaDBConstant;
import sqlancer.mariadb.ast.MariaDBExpression;
import sqlancer.mariadb.ast.MariaDBFunction;
import sqlancer.mariadb.ast.MariaDBFunctionName;
import sqlancer.mariadb.ast.MariaDBInOperation;
import sqlancer.mariadb.ast.MariaDBJoin;
import sqlancer.mariadb.ast.MariaDBPostfixUnaryOperation;
import sqlancer.mariadb.ast.MariaDBSelectStatement;
import sqlancer.mariadb.ast.MariaDBTableReference;
import sqlancer.mariadb.ast.MariaDBText;
import sqlancer.mariadb.ast.MariaDBUnaryPrefixOperation;
import sqlancer.mariadb.gen.MariaDBExpressionGenerator;
import sqlancer.mariadb.ast.MariaDBVisitor;

public class MariaDBTimeEquivalenceOracle implements TestOracle<MariaDBGlobalState> {

    private enum Rule {
        WHERE_TO_SUBQUERY, HAVING_TO_SUBQUERY
    }

    private final MariaDBGlobalState state;
    private final ExpectedErrors errors = new ExpectedErrors();

    public MariaDBTimeEquivalenceOracle(MariaDBGlobalState state) {
        this.state = state;
        MariaDBErrors.addCommonErrors(errors);
    }

    @Override
    public void check() throws Exception {
        MariaDBTables tables = state.getSchema().getRandomTableNonEmptyTables();
        List<MariaDBTable> tableList = tables.getTables();
        if (tableList.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<MariaDBColumn> columns = tables.getColumns();
        MariaDBExpressionGenerator gen = new MariaDBExpressionGenerator(state.getRandomly()).setColumns(columns);

        Rule rule = Randomly.fromOptions(Rule.values());
        switch (rule) {
            case WHERE_TO_SUBQUERY:
                checkWhereToSubquery(gen, tableList, columns);
                break;
            case HAVING_TO_SUBQUERY:
                checkHavingToSubquery(gen, tableList, columns);
                break;
            default:
                throw new AssertionError(rule);
        }
    }

    private void checkWhereToSubquery(MariaDBExpressionGenerator gen, List<MariaDBTable> tables,
            List<MariaDBColumn> columns) throws Exception {
        MariaDBExpression predicate = generateCompoundPredicate(gen);
        MariaDBExpression signatureExpr = buildSignatureExpression(columns, gen);

        List<MariaDBTable> tablesForJoin = new ArrayList<>(tables);
        List<MariaDBJoin> joins = MariaDBJoin.getRandomJoinClauses(tablesForJoin, state.getRandomly());
        List<MariaDBExpression> from = tablesForJoin.stream().map(MariaDBTableReference::new)
                .collect(Collectors.toList());

        MariaDBSelectStatement base = new MariaDBSelectStatement();
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(from);
        base.setJoinClauses(joins);
        base.setWhereClause(predicate);

        MariaDBSelectStatement inner = new MariaDBSelectStatement();
        inner.setFetchColumns(List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(predicate, "ref1")));
        inner.setFromList(from);
        inner.setJoinClauses(joins);

        String baseQuery = MariaDBVisitor.asString(base);
        String innerQuery = MariaDBVisitor.asString(inner);
        String movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private void checkHavingToSubquery(MariaDBExpressionGenerator gen, List<MariaDBTable> tables,
            List<MariaDBColumn> columns) throws Exception {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<MariaDBColumn> groupByColumns = Randomly.nonEmptySubset(columns);
        MariaDBExpression havingPredicate = generateHavingExpression(gen, groupByColumns);
        MariaDBExpression signatureExpr = buildSignatureExpression(groupByColumns,
                new MariaDBExpressionGenerator(state.getRandomly()).setColumns(groupByColumns));

        List<MariaDBTable> tablesForJoin = new ArrayList<>(tables);
        List<MariaDBJoin> joins = MariaDBJoin.getRandomJoinClauses(tablesForJoin, state.getRandomly());
        List<MariaDBExpression> from = tablesForJoin.stream().map(MariaDBTableReference::new)
                .collect(Collectors.toList());
        List<MariaDBExpression> groupByExprs = groupByColumns.stream().map(MariaDBColumnName::new)
                .collect(Collectors.toList());

        MariaDBExpression wherePredicate = Randomly.getBoolean() ? generateCompoundPredicate(gen) : null;

        // Build HAVING as a string so we can refer to projected aliases (MariaDB
        // may not resolve qualified columns like t0.c0 in HAVING reliably).
        String signatureString = MariaDBVisitor.asString(signatureExpr);
        String havingString = MariaDBVisitor.asString(havingPredicate);

        List<String> selectItems = new ArrayList<>();
        selectItems.add(signatureString + " AS sig");
        String havingStringWithAliases = havingString;
        for (int i = 0; i < groupByColumns.size(); i++) {
            MariaDBColumn col = groupByColumns.get(i);
            String alias = "g" + i;
            selectItems.add(col.getFullQualifiedName() + " AS " + alias);
            havingStringWithAliases = havingStringWithAliases.replace(col.getFullQualifiedName(), alias);
        }

        String fromClause = from.stream().map(MariaDBVisitor::asString).collect(Collectors.joining(", "));
        String joinClause = joins.stream().map(MariaDBVisitor::asString).collect(Collectors.joining(""));
        String whereString = wherePredicate == null ? null : MariaDBVisitor.asString(wherePredicate);
        String groupByClause = groupByExprs.stream().map(MariaDBVisitor::asString).collect(Collectors.joining(", "));

        String baseQuery = "SELECT " + String.join(", ", selectItems) + " FROM " + fromClause + joinClause
                + (whereString == null ? "" : " WHERE " + whereString) + " GROUP BY " + groupByClause
                + " HAVING " + havingStringWithAliases;

        String innerQuery = "SELECT " + signatureString + " AS ref0, (" + havingString + ") AS ref1 FROM "
                + fromClause + joinClause + (whereString == null ? "" : " WHERE " + whereString)
                + " GROUP BY " + groupByClause;
        String movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private MariaDBExpression buildSignatureExpression(List<MariaDBColumn> columns, MariaDBExpressionGenerator gen) {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<MariaDBExpression> args = new ArrayList<>();
        boolean first = true;
        for (MariaDBColumn col : columns) {
            if (!first) {
                args.add(MariaDBConstant.createTextConstant("#"));
            }
            args.add(ifNull(new MariaDBColumnName(col)));
            first = false;
        }
        if (gen != null && Randomly.getBoolean()) {
            MariaDBExpression extra = generateSafeScalarExpression(gen);
            if (!first) {
                args.add(MariaDBConstant.createTextConstant("#"));
            }
            args.add(ifNull(extra));
        }
        return new MariaDBFunction(MariaDBFunctionName.CONCAT, args);
    }

    private MariaDBExpression ifNull(MariaDBExpression expr) {
        return new MariaDBFunction(MariaDBFunctionName.IFNULL,
                Arrays.asList(expr, MariaDBConstant.createTextConstant("__NULL__")));
    }

    private MariaDBExpression aliasExpression(MariaDBExpression expr, String alias) {
        return new MariaDBText(expr, " AS " + alias, false);
    }

    private MariaDBExpression generateCompoundPredicate(MariaDBExpressionGenerator gen) {
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        MariaDBExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            MariaDBExpression term = generateSafeScalarExpression(gen);
            if (Randomly.getBoolean()) {
                term = new MariaDBUnaryPrefixOperation(term,
                        MariaDBUnaryPrefixOperation.MariaDBUnaryPrefixOperator.getRandom());
            }
            if (Randomly.getBooleanWithSmallProbability()) {
                term = new MariaDBPostfixUnaryOperation(
                        MariaDBPostfixUnaryOperation.MariaDBPostfixUnaryOperator.getRandom(),
                        term);
            }
            if (predicate == null) {
                predicate = term;
            } else {
                MariaDBBinaryComparisonOperator op = Randomly
                        .fromOptions(MariaDBBinaryComparisonOperator.AND, MariaDBBinaryComparisonOperator.OR);
                predicate = new MariaDBBinaryOperator(predicate, term, op);
            }
        }
        return predicate == null ? generateSafeScalarExpression(gen) : predicate;
    }

    private MariaDBExpression generateSafeScalarExpression(MariaDBExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            MariaDBExpression expr = gen.getRandomExpression();
            if (isSafeScalar(expr, false)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private MariaDBExpression generateSafeScalarExpressionAllowAggregate(MariaDBExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            MariaDBExpression expr = gen.getRandomExpression();
            if (isSafeScalar(expr, true)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private MariaDBExpression generateHavingExpression(MariaDBExpressionGenerator gen,
            List<MariaDBColumn> groupByCols) {
        MariaDBColumn col = Randomly.fromList(groupByCols);
        MariaDBAggregate agg = new MariaDBAggregate(new MariaDBColumnName(col), MariaDBAggregateFunction.COUNT);
        MariaDBExpression right = MariaDBExpressionGenerator.getRandomConstant(state.getRandomly());
        MariaDBBinaryComparisonOperator op = Randomly.fromOptions(MariaDBBinaryComparisonOperator.NOT_EQUAL,
                MariaDBBinaryComparisonOperator.LESS_THAN, MariaDBBinaryComparisonOperator.GREATER_THAN,
                MariaDBBinaryComparisonOperator.GREATER_THAN_EQUAL);
        MariaDBExpression predicate = new MariaDBBinaryOperator(agg, right, op);
        if (Randomly.getBoolean()) {
            MariaDBExpressionGenerator groupByGen = new MariaDBExpressionGenerator(state.getRandomly())
                    .setColumns(groupByCols);
            MariaDBExpression extra = generateSafeScalarExpressionAllowAggregate(groupByGen);
            MariaDBBinaryComparisonOperator joinOp = Randomly
                    .fromOptions(MariaDBBinaryComparisonOperator.AND, MariaDBBinaryComparisonOperator.OR);
            predicate = new MariaDBBinaryOperator(predicate, extra, joinOp);
        }
        return predicate;
    }

    private boolean isSafeScalar(MariaDBExpression expr, boolean allowAggregate) {
        return expr != null && !containsForbiddenExpression(expr, allowAggregate);
    }

    private boolean containsForbiddenExpression(MariaDBExpression expr, boolean allowAggregate) {
        if (expr == null) {
            return false;
        }
        if (!allowAggregate && expr instanceof MariaDBAggregate) {
            return true;
        }
        if (expr instanceof MariaDBSelectStatement || expr instanceof MariaDBJoin
                || expr instanceof MariaDBTableReference) {
            return true;
        }
        if (expr instanceof MariaDBFunction) {
            MariaDBFunction func = (MariaDBFunction) expr;
            if (isNonDeterministicFunction(func.getFunc())) {
                return true;
            }
            for (MariaDBExpression e : func.getArgs()) {
                if (containsForbiddenExpression(e, allowAggregate)) {
                    return true;
                }
            }
            return false;
        }
        if (expr instanceof MariaDBConstant || expr instanceof MariaDBColumnName) {
            return false;
        }
        if (expr instanceof MariaDBUnaryPrefixOperation) {
            return containsForbiddenExpression(((MariaDBUnaryPrefixOperation) expr).getExpr(), allowAggregate);
        }
        if (expr instanceof MariaDBPostfixUnaryOperation) {
            return containsForbiddenExpression(((MariaDBPostfixUnaryOperation) expr).getRandomWhereCondition(),
                    allowAggregate);
        }
        if (expr instanceof MariaDBBinaryOperator) {
            MariaDBBinaryOperator op = (MariaDBBinaryOperator) expr;
            return containsForbiddenExpression(op.getLeft(), allowAggregate)
                    || containsForbiddenExpression(op.getRight(), allowAggregate);
        }
        if (expr instanceof MariaDBInOperation) {
            MariaDBInOperation op = (MariaDBInOperation) expr;
            if (containsForbiddenExpression(op.getExpr(), allowAggregate)) {
                return true;
            }
            for (MariaDBExpression e : op.getList()) {
                if (containsForbiddenExpression(e, allowAggregate)) {
                    return true;
                }
            }
            return false;
        }
        if (expr instanceof MariaDBText) {
            return containsForbiddenExpression(((MariaDBText) expr).getExpr(), allowAggregate);
        }
        return false;
    }

    private boolean isNonDeterministicFunction(MariaDBFunctionName func) {
        if (func == null) {
            return false;
        }
        switch (func.getFunctionName().toUpperCase()) {
            case "RAND":
            case "RANDOM":
            case "UUID":
            case "UUID_SHORT":
            case "NOW":
            case "SYSDATE":
            case "CURRENT_TIMESTAMP":
            case "CURRENT_DATE":
            case "CURRENT_TIME":
            case "CURDATE":
            case "CURTIME":
                return true;
            default:
                return false;
        }
    }
}
