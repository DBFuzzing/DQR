package sqlancer.mysql.oracle;

import java.util.List;
import java.util.stream.Collectors;

import sqlancer.ComparatorHelper;
import sqlancer.IgnoreMeException;
import sqlancer.Randomly;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;
import sqlancer.mysql.MySQLErrors;
import sqlancer.mysql.MySQLGlobalState;
import sqlancer.mysql.MySQLSchema.MySQLColumn;
import sqlancer.mysql.MySQLSchema.MySQLTable;
import sqlancer.mysql.MySQLSchema.MySQLTables;
import sqlancer.mysql.MySQLVisitor;
import sqlancer.mysql.ast.MySQLBetweenOperation;
import sqlancer.mysql.ast.MySQLBinaryComparisonOperation;
import sqlancer.mysql.ast.MySQLBinaryComparisonOperation.BinaryComparisonOperator;
import sqlancer.mysql.ast.MySQLBinaryLogicalOperation;
import sqlancer.mysql.ast.MySQLBinaryOperation;
import sqlancer.mysql.ast.MySQLAggregate;
import sqlancer.mysql.ast.MySQLAggregate.MySQLAggregateFunction;
import sqlancer.mysql.ast.MySQLCaseOperator;
import sqlancer.mysql.ast.MySQLCastOperation;
import sqlancer.mysql.ast.MySQLCollate;
import sqlancer.mysql.ast.MySQLColumnReference;
import sqlancer.mysql.ast.MySQLComputableFunction;
import sqlancer.mysql.ast.MySQLConstant;
import sqlancer.mysql.ast.MySQLExists;
import sqlancer.mysql.ast.MySQLExpression;
import sqlancer.mysql.ast.MySQLInOperation;
import sqlancer.mysql.ast.MySQLJoin;
import sqlancer.mysql.ast.MySQLOrderByTerm;
import sqlancer.mysql.ast.MySQLSelect;
import sqlancer.mysql.ast.MySQLStringExpression;
import sqlancer.mysql.ast.MySQLTableReference;
import sqlancer.mysql.ast.MySQLText;
import sqlancer.mysql.ast.MySQLUnaryPostfixOperation;
import sqlancer.mysql.ast.MySQLUnaryPrefixOperation;
import sqlancer.mysql.ast.MySQLUnaryPrefixOperation.MySQLUnaryPrefixOperator;
import sqlancer.mysql.gen.MySQLExpressionGenerator;

public class MySQLTimeEquivalenceOracle implements TestOracle<MySQLGlobalState> {

    // 教程式说明（整体）：
    // 这个 Oracle 的核心是“等价改写 + 结果比对”。每次 check() 随机挑一种改写规则，
    // 生成一对语义等价的 SQL（base vs moved），执行后比较结果是否一致。
    //
    // 当前覆盖三类等价：
    // 1) WHERE -> 子查询外提/下推；
    // 2) EXISTS -> 子查询外提/下推；
    // 3) HAVING -> 子查询外提/下推（包含聚合谓词）。
    //
    // 输出/对比方式：
    // - 查询的“结果行”会被拼成一个 signature 列（CONCAT + IFNULL），
    // 这样只比较单列即可避免多列对比的复杂性。
    private enum Rule {
        WHERE_TO_SUBQUERY, EXISTS_TO_SUBQUERY, HAVING_TO_SUBQUERY
    }

    private final MySQLGlobalState state;
    private final ExpectedErrors errors = new ExpectedErrors();

    public MySQLTimeEquivalenceOracle(MySQLGlobalState state) {
        this.state = state;
        MySQLErrors.addExpressionErrors(errors);
    }

    @Override
    public void check() throws Exception {
        // 输入：无
        // 输出：无（内部执行多条 SQL 并断言结果相等）
        //
        // 教程式说明：
        // 1) 随机选择一组非空表；
        // 2) 生成谓词/聚合/分组等；
        // 3) 选一个等价规则；
        // 4) 生成两条 SQL 并比较结果。
        MySQLTables tables = state.getSchema().getRandomTableNonEmptyTables();
        List<MySQLTable> tableList = tables.getTables();
        if (tableList.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<MySQLColumn> columns = tables.getColumns();
        MySQLExpressionGenerator gen = new MySQLExpressionGenerator(state).setColumns(columns);

        // 随机选择规则执行，保证不同等价改写都有机会被覆盖
        Rule rule = Randomly.fromOptions(Rule.values());
        switch (rule) {
            case WHERE_TO_SUBQUERY:
                checkWhereToSubquery(gen, tableList, columns);
                break;
            case EXISTS_TO_SUBQUERY:
                checkExistsToSubquery(tableList);
                break;
            case HAVING_TO_SUBQUERY:
                checkHavingToSubquery(gen, tableList, columns);
                break;
            default:
                throw new AssertionError(rule);
        }
    }

    private void checkWhereToSubquery(MySQLExpressionGenerator gen, List<MySQLTable> tables,
            List<MySQLColumn> columns) throws Exception {
        // 输入：
        // - gen: 表达式生成器
        // - tables/columns: 当前选择的表/列
        // 输出：
        // - 无（内部比较两条查询）
        //
        // 教程式说明：
        // 目标是验证 “WHERE P” 与 “把 P 提到子查询再外层过滤” 是否等价。
        //
        // 原始示例：
        // SELECT sig FROM T WHERE P
        // 改写示例：
        // SELECT ref0 FROM (SELECT sig AS ref0, P AS ref1 FROM T) s WHERE ref1
        //
        // 构造原始谓词 P（可包含多项 AND/OR），并冻结为字符串表达式
        // 示例：P = (c0 > 5 AND NOT c1) OR (c2 < 0)
        MySQLExpression predicate = generateCompoundPredicate(gen);
        String predicateString = MySQLVisitor.asString(predicate);
        MySQLExpression frozenPredicate = new MySQLStringExpression(predicateString,
                MySQLConstant.createNullConstant());
        // 构造“行签名”列，用于把多列拼成一列，便于结果集比较
        // 示例：CONCAT(IFNULL(t0.c0,'__NULL__'), '#', IFNULL(t0.c1,'__NULL__'))
        MySQLExpression signatureExpr = buildSignatureExpression(columns, gen);
        MySQLSelect.SelectType selectType = chooseSelectType();

        // 原始查询：SELECT sig FROM T WHERE P
        MySQLSelect base = new MySQLSelect();
        base.setSelectType(selectType);
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(tables.stream().map(MySQLTableReference::new).collect(Collectors.toList()));
        base.setWhereClause(frozenPredicate);

        // 改写查询：
        // SELECT ref0 FROM (SELECT sig AS ref0, P AS ref1 FROM T) s WHERE ref1
        MySQLSelect inner = new MySQLSelect();
        inner.setSelectType(MySQLSelect.SelectType.ALL);
        inner.setFetchColumns(List.of(signatureExpr, frozenPredicate));
        inner.setFromList(tables.stream().map(MySQLTableReference::new).collect(Collectors.toList()));

        String baseQuery = MySQLVisitor.asString(base);
        String innerQuery = MySQLVisitor.asString(inner);
        String movedQuery = "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery + ") AS s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private void checkExistsToSubquery(List<MySQLTable> outerTables) throws Exception {
        // 输入：
        // - outerTables: 外层 FROM 的表集合
        // 输出：
        // - 无（内部比较两条查询）
        //
        // 教程式说明：
        // 目标是验证 “WHERE EXISTS(...) [AND Q]” 与 “把 EXISTS 变成列再过滤” 是否等价。
        //
        // 原始示例：
        // SELECT sig FROM Outer WHERE EXISTS(SELECT 1 FROM Inner WHERE P) AND Q
        // 改写示例：
        // SELECT ref0 FROM (
        // SELECT sig AS ref0, EXISTS(...) AS ref1, Q AS ref2 FROM Outer
        // ) s WHERE ref1 AND ref2
        //
        // 外层 FROM 表集合
        List<MySQLExpression> outerFrom = outerTables.stream().map(MySQLTableReference::new)
                .collect(Collectors.toList());
        List<MySQLColumn> outerColumns = outerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        if (outerColumns.isEmpty()) {
            throw new IgnoreMeException();
        }

        // 内层 EXISTS 子查询所用的表与谓词
        List<MySQLTable> innerTables = Randomly.nonEmptySubset(state.getSchema().getDatabaseTables());
        List<MySQLColumn> innerColumns = innerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        MySQLExpressionGenerator innerGen = new MySQLExpressionGenerator(state).setColumns(innerColumns);
        MySQLExpression innerPredicate = generateSafeScalarExpression(innerGen);

        // EXISTS(SELECT 1 FROM innerTables WHERE innerPredicate)
        MySQLSelect innerSelect = new MySQLSelect();
        innerSelect.setSelectType(MySQLSelect.SelectType.ALL);
        innerSelect.setFetchColumns(List.of(MySQLConstant.createIntConstant(1)));
        innerSelect.setFromList(innerTables.stream().map(MySQLTableReference::new).collect(Collectors.toList()));
        innerSelect.setWhereClause(innerPredicate);
        MySQLExpression existsExpr = new MySQLExists(innerSelect, MySQLConstant.createNullConstant());
        String existsString = MySQLVisitor.asString(existsExpr);
        MySQLExpression frozenExists = new MySQLStringExpression(existsString, MySQLConstant.createNullConstant());

        // 外层签名列，用于比较
        MySQLExpression signatureExpr = buildSignatureExpression(outerColumns, new MySQLExpressionGenerator(state)
                .setColumns(outerColumns));
        MySQLSelect.SelectType selectType = chooseSelectType();

        // 外层可选谓词 Q
        MySQLExpression outerPredicate = Randomly.getBoolean() ? generateCompoundPredicate(
                new MySQLExpressionGenerator(state).setColumns(outerColumns)) : null;
        String outerString = null;
        MySQLExpression frozenOuter = null;
        if (outerPredicate != null) {
            outerString = MySQLVisitor.asString(outerPredicate);
            frozenOuter = new MySQLStringExpression(outerString, MySQLConstant.createNullConstant());
        }

        // 原始查询：
        // SELECT sig FROM Outer WHERE EXISTS(...) [AND Q]
        MySQLSelect base = new MySQLSelect();
        base.setSelectType(selectType);
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(outerFrom);
        if (outerPredicate == null) {
            base.setWhereClause(frozenExists);
        } else {
            String combined = "(" + existsString + ") AND (" + outerString + ")";
            base.setWhereClause(new MySQLStringExpression(combined, MySQLConstant.createNullConstant()));
        }

        // 改写查询：
        // SELECT ref0 FROM (SELECT sig AS ref0, EXISTS(...) AS ref1 [, Q AS ref2] FROM
        // Outer) s
        // WHERE ref1 [AND ref2]
        MySQLSelect inner = new MySQLSelect();
        inner.setSelectType(MySQLSelect.SelectType.ALL);
        if (outerPredicate == null) {
            inner.setFetchColumns(List.of(signatureExpr, frozenExists));
        } else {
            inner.setFetchColumns(List.of(signatureExpr, frozenExists, frozenOuter));
        }
        inner.setFromList(outerFrom);

        String baseQuery = MySQLVisitor.asString(base);
        String innerQuery = MySQLVisitor.asString(inner);
        String movedQuery;
        if (outerPredicate == null) {
            movedQuery = "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery + ") AS s WHERE ref1";
        } else {
            movedQuery = "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery
                    + ") AS s WHERE ref1 AND ref2";
        }

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private void checkHavingToSubquery(MySQLExpressionGenerator gen, List<MySQLTable> tables,
            List<MySQLColumn> columns) throws Exception {
        // 输入：
        // - gen: 表达式生成器（用于 WHERE）
        // - tables/columns: 当前选择的表/列
        // 输出：
        // - 无（内部比较两条查询）
        //
        // 教程式说明：
        // 目标是验证 “HAVING H” 与 “把 H 变成列再过滤” 是否等价。
        //
        // 原始示例：
        // SELECT sig FROM T WHERE P GROUP BY G HAVING H
        // 改写示例：
        // SELECT ref0 FROM (
        // SELECT sig AS ref0, H AS ref1 FROM T WHERE P GROUP BY G
        // ) s WHERE ref1
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        // 选择分组列；HAVING 中允许引用这些列（避免 ONLY_FULL_GROUP_BY 错误）
        List<MySQLColumn> groupByColumns = Randomly.nonEmptySubset(columns);
        // 生成 HAVING 谓词（包含聚合表达式），例如：SUM(t0.c1) > 5 OR COUNT(DISTINCT t0.c2) <= 10
        MySQLExpression havingPredicate = generateHavingExpression(columns, groupByColumns);
        String havingString = MySQLVisitor.asString(havingPredicate);
        MySQLExpression frozenHaving = new MySQLStringExpression(havingString, MySQLConstant.createNullConstant());

        // 可选 WHERE 谓词，保留在子查询里（聚合前过滤）
        MySQLExpression wherePredicate = Randomly.getBoolean() ? generateCompoundPredicate(gen) : null;
        MySQLExpression frozenWhere = null;
        if (wherePredicate != null) {
            String whereString = MySQLVisitor.asString(wherePredicate);
            frozenWhere = new MySQLStringExpression(whereString, MySQLConstant.createNullConstant());
        }

        // sig 是“行签名”，把分组列拼成单列以便比较结果集
        // 这里仅使用 GROUP BY 列，避免 ONLY_FULL_GROUP_BY 错误
        MySQLExpressionGenerator groupByGen = new MySQLExpressionGenerator(state).setColumns(groupByColumns);
        MySQLExpression signatureExpr = buildSignatureExpression(groupByColumns, groupByGen);
        List<MySQLExpression> groupByExprs = groupByColumns.stream().map(c -> new MySQLColumnReference(c, null))
                .collect(Collectors.toList());
        MySQLSelect.SelectType selectType = chooseSelectType();

        // 原始查询：
        // SELECT sig FROM T WHERE P GROUP BY G HAVING H
        //
        // 为避免 HAVING 在某些情况下被遗漏，这里直接拼 SQL 字符串
        // （仍然使用 visitor 生成表达式字符串，避免手写错误）
        String signatureString = MySQLVisitor.asString(signatureExpr);
        String fromClause = tables.stream().map(t -> t.getName()).collect(Collectors.joining(", "));
        String groupByClause = groupByExprs.stream().map(MySQLVisitor::asString).collect(Collectors.joining(", "));
        String whereString = frozenWhere == null ? null : MySQLVisitor.asString(frozenWhere);
        String baseQuery = "SELECT " + selectTypeToSql(selectType) + " " + signatureString + " FROM " + fromClause
                + (whereString == null ? "" : " WHERE " + whereString) + " GROUP BY " + groupByClause + " HAVING "
                + havingString;

        // 等价改写：把 HAVING 谓词作为列 ref1 计算，再在外层 WHERE 过滤
        // 原始：SELECT sig FROM T WHERE P GROUP BY G HAVING H
        // 改写：SELECT ref0 FROM (SELECT sig AS ref0, H AS ref1 FROM T WHERE P GROUP BY G)
        // s WHERE ref1
        String innerQuery = "SELECT " + signatureString + " AS ref0, (" + havingString + ") AS ref1 FROM "
                + fromClause + (whereString == null ? "" : " WHERE " + whereString) + " GROUP BY " + groupByClause;
        String movedQuery = "SELECT " + selectTypeToSql(selectType) + " ref0 FROM (" + innerQuery
                + ") AS s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private MySQLExpression buildSignatureExpression(List<MySQLColumn> columns, MySQLExpressionGenerator gen) {
        // 输入：列集合、表达式生成器
        // 输出：一个字符串表达式，用于拼接“行签名”
        //
        // 教程式说明：
        // 把多列拼成一列（并处理 NULL），这样比较结果集时只需比较一列。
        // 示例：CONCAT(IFNULL(t0.c0,'__NULL__'), '#', IFNULL(t0.c1,'__NULL__'))
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        StringBuilder sb = new StringBuilder();
        // 该表达式把多列拼成一列，用 '#" 分隔，NULL 用 '__NULL__' 占位
        // 目的是把多列结果映射为单列，方便 ComparatorHelper 比较结果集
        sb.append("CONCAT(");
        int parts = 0;
        for (int i = 0; i < columns.size(); i++) {
            MySQLColumn col = columns.get(i);
            if (parts > 0) {
                sb.append(", '#', ");
            }
            sb.append("IFNULL(");
            sb.append(col.getFullQualifiedName());
            sb.append(", '__NULL__')");
            parts++;
        }
        if (gen != null && Randomly.getBoolean()) {
            MySQLExpression extra = generateSafeScalarExpression(gen);
            sb.append(", '#', ");
            sb.append("IFNULL(");
            sb.append(MySQLVisitor.asString(extra));
            sb.append(", '__NULL__')");
        }
        sb.append(")");
        return new MySQLStringExpression(sb.toString(), MySQLConstant.createNullConstant());
    }

    private MySQLSelect.SelectType chooseSelectType() {
        return Randomly.fromOptions(MySQLSelect.SelectType.values());
    }

    private String selectTypeToSql(MySQLSelect.SelectType selectType) {
        switch (selectType) {
            case ALL:
                return "ALL";
            case DISTINCT:
                return "DISTINCT";
            case DISTINCTROW:
                return "DISTINCTROW";
            default:
                throw new AssertionError(selectType);
        }
    }

    private MySQLExpression generateCompoundPredicate(MySQLExpressionGenerator gen) {
        // 输入：表达式生成器
        // 输出：一个复合谓词（AND/OR 组合）
        //
        // 教程式说明：
        // 生成 1~3 个“安全标量表达式”，随机用 AND/OR 连接。
        // 示例：NOT(c0) AND (c1 > 5) OR (c2 = 0)
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        MySQLExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            MySQLExpression term = generateSafeScalarExpression(gen);
            if (Randomly.getBoolean()) {
                term = new MySQLUnaryPrefixOperation(term, MySQLUnaryPrefixOperator.NOT);
            }
            if (predicate == null) {
                predicate = term;
            } else {
                MySQLBinaryLogicalOperation.MySQLBinaryLogicalOperator op = Randomly
                        .fromOptions(MySQLBinaryLogicalOperation.MySQLBinaryLogicalOperator.AND,
                                MySQLBinaryLogicalOperation.MySQLBinaryLogicalOperator.OR);
                predicate = new MySQLBinaryLogicalOperation(predicate, term, op);
            }
        }
        return predicate == null ? generateSafeScalarExpression(gen) : predicate;
    }

    private MySQLExpression generateSafeScalarExpression(MySQLExpressionGenerator gen) {
        // 输入：表达式生成器
        // 输出：安全标量表达式（不会包含子查询/聚合/表引用）
        //
        // 教程式说明：
        // 尝试多次生成表达式，直到符合 isSafeScalar 的安全约束。
        for (int i = 0; i < 100; i++) {
            MySQLExpression expr = gen.generateExpression();
            if (isSafeScalar(expr)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private boolean isSafeScalar(MySQLExpression expr) {
        // 输入：任意表达式
        // 输出：是否“安全标量”
        //
        // 教程式说明：
        // 安全标量 = 不包含子查询/聚合/表引用/ORDER BY/EXISTS 等结构。
        // 这样可以安全嵌入 WHERE/HAVING 谓词中，避免语义或语法异常。
        if (expr == null) {
            return false;
        }
        // 常量或列引用：一定安全
        if (expr instanceof MySQLConstant || expr instanceof MySQLColumnReference) {
            return true;
        }
        if (expr instanceof MySQLUnaryPrefixOperation) {
            return isSafeScalar(((MySQLUnaryPrefixOperation) expr).getExpression());
        }
        if (expr instanceof MySQLUnaryPostfixOperation) {
            return isSafeScalar(((MySQLUnaryPostfixOperation) expr).getExpression());
        }
        if (expr instanceof MySQLBinaryLogicalOperation) {
            MySQLBinaryLogicalOperation op = (MySQLBinaryLogicalOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof MySQLBinaryComparisonOperation) {
            MySQLBinaryComparisonOperation op = (MySQLBinaryComparisonOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof MySQLBinaryOperation) {
            MySQLBinaryOperation op = (MySQLBinaryOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof MySQLCastOperation) {
            return isSafeScalar(((MySQLCastOperation) expr).getExpr());
        }
        if (expr instanceof MySQLInOperation) {
            MySQLInOperation op = (MySQLInOperation) expr;
            if (!isSafeScalar(op.getExpr())) {
                return false;
            }
            for (MySQLExpression e : op.getListElements()) {
                if (!isSafeScalar(e)) {
                    return false;
                }
            }
            return true;
        }
        if (expr instanceof MySQLBetweenOperation) {
            MySQLBetweenOperation op = (MySQLBetweenOperation) expr;
            return isSafeScalar(op.getExpr()) && isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof MySQLCaseOperator) {
            MySQLCaseOperator op = (MySQLCaseOperator) expr;
            if (op.getSwitchCondition() != null && !isSafeScalar(op.getSwitchCondition())) {
                return false;
            }
            for (MySQLExpression e : op.getConditions()) {
                if (!isSafeScalar(e)) {
                    return false;
                }
            }
            for (MySQLExpression e : op.getExpressions()) {
                if (!isSafeScalar(e)) {
                    return false;
                }
            }
            return op.getElseExpr() == null || isSafeScalar(op.getElseExpr());
        }
        if (expr instanceof MySQLComputableFunction) {
            MySQLComputableFunction func = (MySQLComputableFunction) expr;
            for (MySQLExpression e : func.getArguments()) {
                if (!isSafeScalar(e)) {
                    return false;
                }
            }
            return true;
        }
        if (expr instanceof MySQLCollate) {
            return isSafeScalar(((MySQLCollate) expr).getExpression());
        }
        // 以下类型可能包含子查询/聚合/表等结构，不作为“安全标量”
        if (expr instanceof MySQLAggregate || expr instanceof MySQLSelect || expr instanceof MySQLJoin
                || expr instanceof MySQLTableReference || expr instanceof MySQLOrderByTerm || expr instanceof MySQLText
                || expr instanceof MySQLExists) {
            return false;
        }
        return false;
    }

    private MySQLExpression generateHavingExpression(List<MySQLColumn> columns, List<MySQLColumn> groupByColumns) {
        // 输入：全部列、分组列
        // 输出：HAVING 谓词（包含聚合）
        //
        // 教程式说明：
        // HAVING 由 1~2 个“聚合比较”组成，并用 AND/OR 连接。
        // 示例：SUM(c1) > 5 OR COUNT(DISTINCT c2) <= 10
        int terms = Math.min(2, 1 + Randomly.smallNumber());
        MySQLExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            // 每个 term 都是“聚合表达式 与 常量/分组列”的比较
            // 示例：COUNT(*) > 0 / MAX(t0.c1) <= t0.c0
            MySQLExpression aggregatePredicate = generateAggregatePredicate(columns, groupByColumns);
            if (predicate == null) {
                predicate = aggregatePredicate;
            } else {
                MySQLBinaryLogicalOperation.MySQLBinaryLogicalOperator op = Randomly
                        .fromOptions(MySQLBinaryLogicalOperation.MySQLBinaryLogicalOperator.AND,
                                MySQLBinaryLogicalOperation.MySQLBinaryLogicalOperator.OR);
                predicate = new MySQLBinaryLogicalOperation(predicate, aggregatePredicate, op);
            }
        }
        return predicate;
    }

    private MySQLExpression generateAggregatePredicate(List<MySQLColumn> columns, List<MySQLColumn> groupByColumns) {
        // 输入：全部列、分组列
        // 输出：一个“聚合表达式 与 常量/分组列”的比较
        //
        // 教程式说明：
        // 聚合表达式形如：SUM(col) / COUNT(col) / MIN(col) / MAX(col)
        // 比较右侧：优先用常量，否则用分组列（保证 ONLY_FULL_GROUP_BY 合法）
        //
        // 示例：
        // COUNT(t0.c0) > 0
        // MAX(t0.c3) <= t0.c1 (t0.c1 必须在 GROUP BY 中)
        MySQLAggregateFunction func = Randomly.fromOptions(MySQLAggregateFunction.values());
        int nrArgs = func.isVariadic() ? 1 + Randomly.smallNumber() : 1;
        List<MySQLExpression> args = new java.util.ArrayList<>();
        for (int i = 0; i < nrArgs; i++) {
            MySQLColumn col = Randomly.fromList(columns);
            args.add(new MySQLColumnReference(col, null));
        }
        MySQLExpression aggregateExpr = new MySQLAggregate(args, func);

        // 右侧表达式：优先用常量，否则用分组列（保证 ONLY_FULL_GROUP_BY 合法）
        MySQLExpression rightExpr;
        // 为避免 HAVING 中出现未分组的裸列（ONLY_FULL_GROUP_BY），右侧只用常量
        rightExpr = MySQLConstant.createIntConstant(state.getRandomly().getInteger());
        BinaryComparisonOperator op = Randomly.fromOptions(BinaryComparisonOperator.EQUALS,
                BinaryComparisonOperator.NOT_EQUALS, BinaryComparisonOperator.LESS,
                BinaryComparisonOperator.LESS_EQUALS,
                BinaryComparisonOperator.GREATER, BinaryComparisonOperator.GREATER_EQUALS);
        return new MySQLBinaryComparisonOperation(aggregateExpr, rightExpr, op);
    }
}
