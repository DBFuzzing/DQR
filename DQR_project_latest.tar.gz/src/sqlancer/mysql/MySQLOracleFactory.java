package sqlancer.mysql;

import java.sql.SQLException;

import sqlancer.OracleFactory;
import sqlancer.common.oracle.TestOracle;
import sqlancer.mysql.oracle.MySQLTimeEquivalenceOracle;


public enum MySQLOracleFactory implements OracleFactory<MySQLGlobalState> {

    TIME_EQUIV {
        @Override
        public TestOracle<MySQLGlobalState> create(MySQLGlobalState globalState) throws SQLException {
            return new MySQLTimeEquivalenceOracle(globalState);
        }
    };
}
