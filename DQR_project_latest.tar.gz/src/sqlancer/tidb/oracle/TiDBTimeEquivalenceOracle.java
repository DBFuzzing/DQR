package sqlancer.tidb.oracle;

import java.util.List;
import java.util.stream.Collectors;

import sqlancer.ComparatorHelper;
import sqlancer.IgnoreMeException;
import sqlancer.Randomly;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;
import sqlancer.tidb.TiDBErrors;
import sqlancer.tidb.TiDBExpressionGenerator;
import sqlancer.tidb.TiDBProvider.TiDBGlobalState;
import sqlancer.tidb.TiDBSchema.TiDBColumn;
import sqlancer.tidb.TiDBSchema.TiDBTable;
import sqlancer.tidb.TiDBSchema.TiDBTables;
import sqlancer.tidb.ast.TiDBAggregate;
import sqlancer.tidb.ast.TiDBBinaryArithmeticOperation;
import sqlancer.tidb.ast.TiDBBinaryBitOperation;
import sqlancer.tidb.ast.TiDBBinaryComparisonOperation;
import sqlancer.tidb.ast.TiDBBinaryLogicalOperation;
import sqlancer.tidb.ast.TiDBCase;
import sqlancer.tidb.ast.TiDBCastOperation;
import sqlancer.tidb.ast.TiDBCollate;
import sqlancer.tidb.ast.TiDBColumnReference;
import sqlancer.tidb.ast.TiDBConstant;
import sqlancer.tidb.ast.TiDBExpression;
import sqlancer.tidb.ast.TiDBFunctionCall;
import sqlancer.tidb.ast.TiDBJoin;
import sqlancer.tidb.ast.TiDBOrderingTerm;
import sqlancer.tidb.ast.TiDBRegexOperation;
import sqlancer.tidb.ast.TiDBSelect;
import sqlancer.tidb.ast.TiDBTableReference;
import sqlancer.tidb.ast.TiDBText;
import sqlancer.tidb.ast.TiDBUnaryPostfixOperation;
import sqlancer.tidb.ast.TiDBUnaryPrefixOperation;
import sqlancer.tidb.ast.TiDBUnaryPrefixOperation.TiDBUnaryPrefixOperator;
import sqlancer.tidb.visitor.TiDBVisitor;

public class TiDBTimeEquivalenceOracle implements TestOracle<TiDBGlobalState> {

    private enum Rule {
        WHERE_TO_SUBQUERY, EXISTS_TO_SUBQUERY, HAVING_TO_SUBQUERY
    }

    private final TiDBGlobalState state;
    private final ExpectedErrors errors = new ExpectedErrors();

    public TiDBTimeEquivalenceOracle(TiDBGlobalState state) {
        this.state = state;
        TiDBErrors.addExpressionErrors(errors);
    }

    @Override
    public void check() throws Exception {
        TiDBTables tables = state.getSchema().getRandomTableNonEmptyTables();
        List<TiDBTable> tableList = tables.getTables();
        if (tableList.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<TiDBColumn> columns = tables.getColumns();
        TiDBExpressionGenerator gen = new TiDBExpressionGenerator(state).setColumns(columns);

        Rule rule = Randomly.fromOptions(Rule.values());
        switch (rule) {
            case WHERE_TO_SUBQUERY:
                checkWhereToSubquery(gen, tableList, columns);
                break;
            case EXISTS_TO_SUBQUERY:
                checkExistsToSubquery(tableList);
                break;
            case HAVING_TO_SUBQUERY:
                checkHavingToSubquery(gen, tableList, columns);
                break;
            default:
                throw new AssertionError(rule);
        }
    }

    private void checkWhereToSubquery(TiDBExpressionGenerator gen, List<TiDBTable> tables, List<TiDBColumn> columns)
            throws Exception {
        TiDBExpression predicate = generateCompoundPredicate(gen);
        String predicateString = TiDBVisitor.asString(predicate);
        TiDBExpression frozenPredicate = new TiDBText(predicateString);
        TiDBExpression signatureExpr = buildSignatureExpression(columns, gen);

        TiDBSelect base = new TiDBSelect();
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(tables.stream().map(TiDBTableReference::new).collect(Collectors.toList()));
        base.setWhereClause(frozenPredicate);

        TiDBSelect inner = new TiDBSelect();
        inner.setFetchColumns(
                List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(frozenPredicate, "ref1")));
        inner.setFromList(tables.stream().map(TiDBTableReference::new).collect(Collectors.toList()));

        String baseQuery = TiDBVisitor.asString(base);
        String innerQuery = TiDBVisitor.asString(inner);
        String movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private void checkExistsToSubquery(List<TiDBTable> outerTables) throws Exception {
        List<TiDBExpression> outerFrom = outerTables.stream().map(TiDBTableReference::new).collect(Collectors.toList());
        List<TiDBColumn> outerColumns = outerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        if (outerColumns.isEmpty()) {
            throw new IgnoreMeException();
        }

        List<TiDBTable> innerTables = Randomly.nonEmptySubset(state.getSchema().getDatabaseTables());
        List<TiDBColumn> innerColumns = innerTables.stream().flatMap(t -> t.getColumns().stream())
                .collect(Collectors.toList());
        TiDBExpressionGenerator innerGen = new TiDBExpressionGenerator(state).setColumns(innerColumns);
        TiDBExpression innerPredicate = generateSafeScalarExpression(innerGen);

        TiDBSelect innerSelect = new TiDBSelect();
        innerSelect.setFetchColumns(List.of(TiDBConstant.createIntConstant(1)));
        innerSelect.setFromList(innerTables.stream().map(TiDBTableReference::new).collect(Collectors.toList()));
        innerSelect.setWhereClause(innerPredicate);

        String existsString = "EXISTS (" + TiDBVisitor.asString(innerSelect) + ")";
        TiDBExpression frozenExists = new TiDBText(existsString);

        TiDBExpression signatureExpr = buildSignatureExpression(outerColumns,
                new TiDBExpressionGenerator(state).setColumns(outerColumns));

        TiDBExpression outerPredicate = Randomly.getBoolean() ? generateCompoundPredicate(
                new TiDBExpressionGenerator(state).setColumns(outerColumns)) : null;
        String outerString = null;
        TiDBExpression frozenOuter = null;
        if (outerPredicate != null) {
            outerString = TiDBVisitor.asString(outerPredicate);
            frozenOuter = new TiDBText(outerString);
        }

        TiDBSelect base = new TiDBSelect();
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(outerFrom);
        if (outerPredicate == null) {
            base.setWhereClause(frozenExists);
        } else {
            String combined = "(" + existsString + ") AND (" + outerString + ")";
            base.setWhereClause(new TiDBText(combined));
        }

        TiDBSelect inner = new TiDBSelect();
        if (outerPredicate == null) {
            inner.setFetchColumns(
                    List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(frozenExists, "ref1")));
        } else {
            inner.setFetchColumns(List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(frozenExists, "ref1"),
                    aliasExpression(frozenOuter, "ref2")));
        }
        inner.setFromList(outerFrom);

        String baseQuery = TiDBVisitor.asString(base);
        String innerQuery = TiDBVisitor.asString(inner);
        String movedQuery;
        if (outerPredicate == null) {
            movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1";
        } else {
            movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1 AND ref2";
        }

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private void checkHavingToSubquery(TiDBExpressionGenerator gen, List<TiDBTable> tables, List<TiDBColumn> columns)
            throws Exception {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<TiDBColumn> groupByColumns = Randomly.nonEmptySubset(columns);
        TiDBExpression havingPredicate = generateHavingExpression(groupByColumns);
        String havingString = TiDBVisitor.asString(havingPredicate);
        TiDBExpression frozenHaving = new TiDBText(havingString);

        TiDBExpression wherePredicate = Randomly.getBoolean() ? generateCompoundPredicate(gen) : null;
        TiDBExpression frozenWhere = null;
        if (wherePredicate != null) {
            frozenWhere = new TiDBText(TiDBVisitor.asString(wherePredicate));
        }

        TiDBExpression signatureExpr = buildSignatureExpression(groupByColumns,
                new TiDBExpressionGenerator(state).setColumns(groupByColumns));
        List<TiDBExpression> groupByExprs = groupByColumns.stream().map(TiDBColumnReference::new)
                .collect(Collectors.toList());

        TiDBSelect base = new TiDBSelect();
        base.setFetchColumns(List.of(signatureExpr));
        base.setFromList(tables.stream().map(TiDBTableReference::new).collect(Collectors.toList()));
        if (frozenWhere != null) {
            base.setWhereClause(frozenWhere);
        }
        base.setGroupByClause(groupByExprs);
        base.setHavingClause(frozenHaving);

        TiDBSelect inner = new TiDBSelect();
        inner.setFetchColumns(List.of(aliasExpression(signatureExpr, "ref0"), aliasExpression(frozenHaving, "ref1")));
        inner.setFromList(tables.stream().map(TiDBTableReference::new).collect(Collectors.toList()));
        if (frozenWhere != null) {
            inner.setWhereClause(frozenWhere);
        }
        inner.setGroupByClause(groupByExprs);

        String baseQuery = TiDBVisitor.asString(base);
        String innerQuery = TiDBVisitor.asString(inner);
        String movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1";

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private TiDBExpression buildSignatureExpression(List<TiDBColumn> columns, TiDBExpressionGenerator gen) {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        StringBuilder sb = new StringBuilder();
        sb.append("CONCAT(");
        int parts = 0;
        for (int i = 0; i < columns.size(); i++) {
            TiDBColumn col = columns.get(i);
            if (parts > 0) {
                sb.append(", '#', ");
            }
            sb.append("IFNULL(");
            sb.append(col.getFullQualifiedName());
            sb.append(", '__NULL__')");
            parts++;
        }
        if (gen != null && Randomly.getBoolean()) {
            TiDBExpression extra = generateSafeScalarExpression(gen);
            sb.append(", '#', ");
            sb.append("IFNULL(");
            sb.append(TiDBVisitor.asString(extra));
            sb.append(", '__NULL__')");
        }
        sb.append(")");
        return new TiDBText(sb.toString());
    }

    private TiDBExpression generateCompoundPredicate(TiDBExpressionGenerator gen) {
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        TiDBExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            TiDBExpression term = generateSafeScalarExpression(gen);
            if (Randomly.getBoolean()) {
                term = new TiDBUnaryPrefixOperation(term, TiDBUnaryPrefixOperator.NOT);
            }
            if (predicate == null) {
                predicate = term;
            } else {
                TiDBBinaryLogicalOperation.TiDBBinaryLogicalOperator op = Randomly
                        .fromOptions(TiDBBinaryLogicalOperation.TiDBBinaryLogicalOperator.AND,
                                TiDBBinaryLogicalOperation.TiDBBinaryLogicalOperator.OR);
                predicate = new TiDBBinaryLogicalOperation(predicate, term, op);
            }
        }
        return predicate == null ? generateSafeScalarExpression(gen) : predicate;
    }

    private TiDBExpression generateSafeScalarExpression(TiDBExpressionGenerator gen) {
        for (int i = 0; i < 100; i++) {
            TiDBExpression expr = gen.generateExpression();
            if (isSafeScalar(expr)) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private TiDBExpression generateHavingExpression(List<TiDBColumn> groupByColumns) {
        TiDBExpression left = Randomly.getBoolean() ? generateAggregateAtom(groupByColumns)
                : generateGroupByScalarAtom(groupByColumns);
        if (Randomly.getBoolean()) {
            return left;
        }
        TiDBExpression right = Randomly.getBoolean() ? generateAggregateAtom(groupByColumns)
                : generateGroupByScalarAtom(groupByColumns);
        TiDBBinaryLogicalOperation.TiDBBinaryLogicalOperator logicalOp = Randomly
                .fromOptions(TiDBBinaryLogicalOperation.TiDBBinaryLogicalOperator.AND,
                        TiDBBinaryLogicalOperation.TiDBBinaryLogicalOperator.OR);
        TiDBExpression combined = new TiDBBinaryLogicalOperation(left, right, logicalOp);
        if (Randomly.getBoolean()) {
            return new TiDBUnaryPrefixOperation(combined, TiDBUnaryPrefixOperator.NOT);
        }
        return combined;
    }

    private TiDBExpression generateAggregateAtom(List<TiDBColumn> groupByColumns) {
        TiDBExpression left = generateAggregateValue(groupByColumns);
        TiDBExpression right;
        if (Randomly.getBoolean()) {
            right = generateAggregateValue(groupByColumns);
        } else {
            right = TiDBConstant.createIntConstant(state.getRandomly().getInteger());
        }
        TiDBBinaryComparisonOperation.TiDBComparisonOperator op = Randomly
                .fromOptions(TiDBBinaryComparisonOperation.TiDBComparisonOperator.GREATER,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.GREATER_EQUALS,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.SMALLER,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.SMALLER_EQUALS,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.NOT_EQUALS,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.EQUALS);
        return new TiDBBinaryComparisonOperation(left, right, op);
    }

    private TiDBExpression generateAggregateValue(List<TiDBColumn> groupByColumns) {
        TiDBColumn aggColumn = Randomly.fromList(groupByColumns);
        TiDBAggregate.TiDBAggregateFunction function = TiDBAggregate.TiDBAggregateFunction.getRandom();
        return new TiDBAggregate(List.of(new TiDBColumnReference(aggColumn)), function);
    }

    private TiDBExpression generateGroupByScalarAtom(List<TiDBColumn> groupByColumns) {
        TiDBExpressionGenerator groupByGen = new TiDBExpressionGenerator(state).setColumns(groupByColumns);
        TiDBExpression left = generateSafeScalarExpression(groupByGen);
        if (Randomly.getBoolean()) {
            return left;
        }
        TiDBExpression right = generateSafeScalarExpression(groupByGen);
        TiDBBinaryComparisonOperation.TiDBComparisonOperator op = Randomly
                .fromOptions(TiDBBinaryComparisonOperation.TiDBComparisonOperator.GREATER,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.GREATER_EQUALS,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.SMALLER,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.SMALLER_EQUALS,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.NOT_EQUALS,
                        TiDBBinaryComparisonOperation.TiDBComparisonOperator.EQUALS);
        return new TiDBBinaryComparisonOperation(left, right, op);
    }

    private boolean isSafeScalar(TiDBExpression expr) {
        if (expr == null) {
            return false;
        }
        if (expr instanceof TiDBConstant || expr instanceof TiDBColumnReference) {
            return true;
        }
        if (expr instanceof TiDBUnaryPrefixOperation) {
            return isSafeScalar(((TiDBUnaryPrefixOperation) expr).getExpression());
        }
        if (expr instanceof TiDBUnaryPostfixOperation) {
            return isSafeScalar(((TiDBUnaryPostfixOperation) expr).getExpression());
        }
        if (expr instanceof TiDBBinaryLogicalOperation) {
            TiDBBinaryLogicalOperation op = (TiDBBinaryLogicalOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof TiDBBinaryComparisonOperation) {
            TiDBBinaryComparisonOperation op = (TiDBBinaryComparisonOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof TiDBBinaryBitOperation) {
            TiDBBinaryBitOperation op = (TiDBBinaryBitOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof TiDBBinaryArithmeticOperation) {
            TiDBBinaryArithmeticOperation op = (TiDBBinaryArithmeticOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof TiDBCastOperation) {
            return isSafeScalar(((TiDBCastOperation) expr).getExpr());
        }
        if (expr instanceof TiDBRegexOperation) {
            TiDBRegexOperation op = (TiDBRegexOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof TiDBFunctionCall) {
            TiDBFunctionCall func = (TiDBFunctionCall) expr;
            for (TiDBExpression e : func.getArgs()) {
                if (!isSafeScalar(e)) {
                    return false;
                }
            }
            return true;
        }
        if (expr instanceof TiDBCase) {
            TiDBCase op = (TiDBCase) expr;
            if (op.getSwitchCondition() != null && !isSafeScalar(op.getSwitchCondition())) {
                return false;
            }
            for (TiDBExpression e : op.getConditions()) {
                if (!isSafeScalar(e)) {
                    return false;
                }
            }
            for (TiDBExpression e : op.getExpressions()) {
                if (!isSafeScalar(e)) {
                    return false;
                }
            }
            return op.getElseExpr() == null || isSafeScalar(op.getElseExpr());
        }
        if (expr instanceof TiDBCollate) {
            return isSafeScalar(((TiDBCollate) expr).getExpression());
        }
        if (expr instanceof TiDBAggregate || expr instanceof TiDBSelect || expr instanceof TiDBJoin
                || expr instanceof TiDBTableReference || expr instanceof TiDBOrderingTerm || expr instanceof TiDBText) {
            return false;
        }
        return false;
    }

    private TiDBExpression aliasExpression(TiDBExpression expr, String alias) {
        return new TiDBText(TiDBVisitor.asString(expr) + " AS " + alias);
    }
}
