package sqlancer.tidb;

import java.sql.SQLException;

import sqlancer.OracleFactory;
import sqlancer.common.oracle.TestOracle;
import sqlancer.tidb.oracle.TiDBTimeEquivalenceOracle;


public enum TiDBOracleFactory implements OracleFactory<TiDBProvider.TiDBGlobalState> {
    TIME_EQUIV {
        @Override
        public TestOracle<TiDBProvider.TiDBGlobalState> create(TiDBProvider.TiDBGlobalState globalState)
                throws SQLException {
            return new TiDBTimeEquivalenceOracle(globalState);
        }
    };

}
