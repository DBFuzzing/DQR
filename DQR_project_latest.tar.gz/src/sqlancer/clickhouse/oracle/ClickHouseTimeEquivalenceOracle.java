package sqlancer.clickhouse.oracle;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.clickhouse.data.ClickHouseDataType;

import sqlancer.ComparatorHelper;
import sqlancer.IgnoreMeException;
import sqlancer.Randomly;
import sqlancer.clickhouse.ClickHouseErrors;
import sqlancer.clickhouse.ClickHouseProvider.ClickHouseGlobalState;
import sqlancer.clickhouse.ClickHouseSchema.ClickHouseColumn;
import sqlancer.clickhouse.ClickHouseSchema.ClickHouseLancerDataType;
import sqlancer.clickhouse.ClickHouseSchema.ClickHouseTable;
import sqlancer.clickhouse.ClickHouseVisitor;
import sqlancer.clickhouse.ast.ClickHouseAggregate;
import sqlancer.clickhouse.ast.ClickHouseAggregate.ClickHouseAggregateFunction;
import sqlancer.clickhouse.ast.ClickHouseBinaryArithmeticOperation;
import sqlancer.clickhouse.ast.ClickHouseBinaryComparisonOperation;
import sqlancer.clickhouse.ast.ClickHouseBinaryFunctionOperation;
import sqlancer.clickhouse.ast.ClickHouseBinaryLogicalOperation;
import sqlancer.clickhouse.ast.ClickHouseCastOperation;
import sqlancer.clickhouse.ast.ClickHouseColumnReference;
import sqlancer.clickhouse.ast.ClickHouseConstant;
import sqlancer.clickhouse.ast.ClickHouseExpression;
import sqlancer.clickhouse.ast.ClickHouseUnaryPostfixOperation;
import sqlancer.clickhouse.ast.ClickHouseUnaryFunctionOperation;
import sqlancer.clickhouse.ast.ClickHouseUnaryPrefixOperation;
import sqlancer.clickhouse.gen.ClickHouseExpressionGenerator;
import sqlancer.common.oracle.TestOracle;
import sqlancer.common.query.ExpectedErrors;

public class ClickHouseTimeEquivalenceOracle implements TestOracle<ClickHouseGlobalState> {

    private enum Rule {
        WHERE_TO_SUBQUERY, HAVING_TO_SUBQUERY
    }

    private static final String NULL_SENTINEL = "'__NULL__'";
    private static final String WHERE_SETTINGS = " SETTINGS enable_optimize_predicate_expression=0";
    private static final String HAVING_SETTINGS = " SETTINGS aggregate_functions_null_for_empty=1, enable_optimize_predicate_expression=0";

    private final ClickHouseGlobalState state;
    private final ExpectedErrors errors = new ExpectedErrors();

    public ClickHouseTimeEquivalenceOracle(ClickHouseGlobalState state) {
        this.state = state;
        ClickHouseErrors.addExpectedExpressionErrors(errors);
    }

    @Override
    public void check() throws SQLException {
        List<ClickHouseTable> allTables = state.getSchema().getRandomTableNonEmptyTables().getTables();
        if (allTables.isEmpty()) {
            throw new IgnoreMeException();
        }
        ClickHouseTable table = Randomly.fromList(allTables);
        List<ClickHouseColumn> columns = table.getColumns().stream().filter(c -> !c.isAlias() && !c.isMaterialized())
                .collect(Collectors.toList());
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }

        Rule rule = Randomly.fromOptions(Rule.values());
        switch (rule) {
            case WHERE_TO_SUBQUERY:
                checkWhereToSubquery(table, columns);
                break;
            case HAVING_TO_SUBQUERY:
                checkHavingToSubquery(table, columns);
                break;
            default:
                throw new AssertionError(rule);
        }
    }

    private void checkWhereToSubquery(ClickHouseTable table, List<ClickHouseColumn> columns) throws SQLException {
        ClickHouseExpressionGenerator gen = new ClickHouseExpressionGenerator(state);
        String predicateString = generateCompoundPredicate(columns);
        String signatureExpr = buildSignatureExpression(columns, gen);
        String fromClause = table.getName();

        String baseQuery = "SELECT " + signatureExpr + " FROM " + fromClause + " WHERE " + predicateString
                + WHERE_SETTINGS;
        String innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + predicateString + ") AS ref1 FROM "
                + fromClause;
        String movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1" + WHERE_SETTINGS;

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private void checkHavingToSubquery(ClickHouseTable table, List<ClickHouseColumn> columns) throws SQLException {
        List<ClickHouseColumn> groupByColumns = Randomly.nonEmptySubset(columns);
        String havingString = generateHavingExpression(groupByColumns);

        String whereString = Randomly.getBoolean() ? generateCompoundPredicate(columns) : null;

        String signatureExpr = buildSignatureExpression(groupByColumns, null);
        String fromClause = table.getName();
        String groupByClause = groupByColumns.stream().map(ClickHouseColumn::getFullQualifiedName)
                .collect(Collectors.joining(", "));

        String baseQuery = "SELECT " + signatureExpr + " FROM " + fromClause
                + (whereString == null ? "" : " WHERE " + whereString) + " GROUP BY " + groupByClause + " HAVING "
                + havingString + HAVING_SETTINGS;

        String innerQuery = "SELECT " + signatureExpr + " AS ref0, (" + havingString + ") AS ref1 FROM " + fromClause
                + (whereString == null ? "" : " WHERE " + whereString) + " GROUP BY " + groupByClause;

        String movedQuery = "SELECT ref0 FROM (" + innerQuery + ") AS s WHERE ref1" + HAVING_SETTINGS;

        List<String> baseResult = ComparatorHelper.getResultSetFirstColumnAsString(baseQuery, errors, state);
        List<String> movedResult = ComparatorHelper.getResultSetFirstColumnAsString(movedQuery, errors, state);
        ComparatorHelper.assumeResultSetsAreEqual(baseResult, movedResult, baseQuery, List.of(movedQuery), state);
    }

    private String buildSignatureExpression(List<ClickHouseColumn> columns, ClickHouseExpressionGenerator gen) {
        if (columns.isEmpty()) {
            throw new IgnoreMeException();
        }
        List<String> parts = new ArrayList<>();
        for (ClickHouseColumn column : columns) {
            parts.add(stringifyExpression(column.getFullQualifiedName()));
        }
        if (gen != null && Randomly.getBoolean()) {
            ClickHouseExpression extra = generateScalarValue(columns, gen);
            parts.add(stringifyExpression(ClickHouseVisitor.asString(extra)));
        }
        return "concat(" + String.join(", '#', ", parts) + ")";
    }

    private String stringifyExpression(String expr) {
        return "if(isNull(" + expr + "), " + NULL_SENTINEL + ", toString(" + expr + "))";
    }

    private String generateCompoundPredicate(List<ClickHouseColumn> columns) {
        int terms = Math.min(3, 1 + Randomly.smallNumber());
        ClickHouseExpression predicate = null;
        for (int i = 0; i < terms; i++) {
            ClickHouseExpression term = generatePredicateAtom(columns);
            if (Randomly.getBoolean()) {
                term = new ClickHouseUnaryPrefixOperation(term,
                        ClickHouseUnaryPrefixOperation.ClickHouseUnaryPrefixOperator.NOT);
            }
            if (predicate == null) {
                predicate = term;
            } else {
                predicate = new ClickHouseBinaryLogicalOperation(predicate, term,
                        Randomly.fromOptions(ClickHouseBinaryLogicalOperation.ClickHouseBinaryLogicalOperator.AND,
                                ClickHouseBinaryLogicalOperation.ClickHouseBinaryLogicalOperator.OR));
            }
        }
        return ClickHouseVisitor.asString(predicate);
    }

    private ClickHouseExpression generatePredicateAtom(List<ClickHouseColumn> columns) {
        return generateGroupByScalarAtom(columns);
    }

    private String generateHavingExpression(List<ClickHouseColumn> groupByColumns) {
        ClickHouseExpression left = Randomly.getBoolean() ? generateAggregateAtom(groupByColumns)
                : generateGroupByScalarAtom(groupByColumns);
        if (Randomly.getBoolean()) {
            return ClickHouseVisitor.asString(left);
        }
        ClickHouseExpression right = Randomly.getBoolean() ? generateAggregateAtom(groupByColumns)
                : generateGroupByScalarAtom(groupByColumns);
        ClickHouseExpression predicate = new ClickHouseBinaryLogicalOperation(left, right,
                Randomly.fromOptions(ClickHouseBinaryLogicalOperation.ClickHouseBinaryLogicalOperator.AND,
                        ClickHouseBinaryLogicalOperation.ClickHouseBinaryLogicalOperator.OR));
        if (Randomly.getBoolean()) {
            predicate = new ClickHouseUnaryPrefixOperation(predicate,
                    ClickHouseUnaryPrefixOperation.ClickHouseUnaryPrefixOperator.NOT);
        }
        return ClickHouseVisitor.asString(predicate);
    }

    private ClickHouseExpression generateAggregateAtom(List<ClickHouseColumn> groupByColumns) {
        TypedClickHouseExpression left = generateAggregateValue(groupByColumns, null);
        TypedClickHouseExpression right;
        if (Randomly.getBoolean()) {
            right = generateAggregateValue(groupByColumns, left.type);
        } else {
            right = new TypedClickHouseExpression(generateComparableConstant(left.type), left.type);
        }
        return new ClickHouseBinaryComparisonOperation(left.expr, right.expr,
                Randomly.fromOptions(ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.EQUALS,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.NOT_EQUALS,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.SMALLER,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.SMALLER_EQUALS,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.GREATER,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.GREATER_EQUALS));
    }

    private ClickHouseExpression generateGroupByScalarAtom(List<ClickHouseColumn> groupByColumns) {
        TypedClickHouseExpression leftValue = generateSafeScalarValue(groupByColumns, null);
        ClickHouseExpression left = leftValue.expr;
        if (Randomly.getBoolean()) {
            return new ClickHouseUnaryPostfixOperation(left,
                    Randomly.fromOptions(ClickHouseUnaryPostfixOperation.ClickHouseUnaryPostfixOperator.IS_NULL,
                            ClickHouseUnaryPostfixOperation.ClickHouseUnaryPostfixOperator.IS_NOT_NULL),
                    false);
        }
        if (leftValue.type == ClickHouseDataType.String && Randomly.getBoolean()) {
            return generateLikeAtom(groupByColumns, leftValue);
        }
        TypedClickHouseExpression rightValue;
        if (Randomly.getBoolean()) {
            rightValue = generateSafeScalarValue(groupByColumns, leftValue.type);
        } else {
            rightValue = new TypedClickHouseExpression(generateComparableConstant(leftValue.type), leftValue.type);
        }
        return new ClickHouseBinaryComparisonOperation(left, rightValue.expr,
                Randomly.fromOptions(ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.EQUALS,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.NOT_EQUALS,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.SMALLER,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.SMALLER_EQUALS,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.GREATER,
                        ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.GREATER_EQUALS));
    }

    private TypedClickHouseExpression generateAggregateValue(List<ClickHouseColumn> groupByColumns,
            ClickHouseDataType requiredType) {
        List<ClickHouseAggregateFunction> candidates = new ArrayList<>();
        for (ClickHouseAggregateFunction func : ClickHouseAggregateFunction.values()) {
            if (requiredType == null || func.supportsReturnType(requiredType)) {
                candidates.add(func);
            }
        }
        if (candidates.isEmpty()) {
            throw new IgnoreMeException();
        }
        for (int i = 0; i < 100; i++) {
            ClickHouseAggregateFunction func = Randomly.fromList(candidates);
            TypedClickHouseExpression expr = createAggregateValue(groupByColumns, func, requiredType);
            if (expr != null) {
                return expr;
            }
        }
        throw new IgnoreMeException();
    }

    private TypedClickHouseExpression createAggregateValue(List<ClickHouseColumn> groupByColumns,
            ClickHouseAggregateFunction func, ClickHouseDataType requiredType) {
        switch (func) {
            case COUNT: {
                ClickHouseExpression arg = generateSafeScalarValue(groupByColumns, null).expr;
                return new TypedClickHouseExpression(new ClickHouseAggregate(arg, func),
                        ClickHouseDataType.Int64);
            }
            case AVG:
            case SUM: {
                ClickHouseColumn column = getRandomColumnOfTypes(groupByColumns,
                        List.of(ClickHouseDataType.Int8, ClickHouseDataType.Int16, ClickHouseDataType.Int32,
                                ClickHouseDataType.Int64, ClickHouseDataType.UInt8, ClickHouseDataType.UInt16,
                                ClickHouseDataType.UInt32, ClickHouseDataType.UInt64, ClickHouseDataType.Float32,
                                ClickHouseDataType.Float64));
                if (column == null) {
                    return null;
                }
                ClickHouseDataType resultType = requiredType != null ? requiredType : column.getType().getType();
                if (!func.supportsReturnType(resultType)) {
                    resultType = func.getRandomReturnType().getType();
                }
                ClickHouseExpression arg = generateSafeScalarValue(groupByColumns, column.getType().getType()).expr;
                return new TypedClickHouseExpression(new ClickHouseAggregate(arg, func),
                        resultType);
            }
            case MIN:
            case MAX: {
                TypedClickHouseExpression arg = generateSafeScalarValue(groupByColumns, requiredType);
                return new TypedClickHouseExpression(new ClickHouseAggregate(arg.expr, func), arg.type);
            }
            default:
                return null;
        }
    }

    private ClickHouseExpression generateScalarValue(List<ClickHouseColumn> columns,
            ClickHouseExpressionGenerator gen) {
        return generateSafeScalarValue(columns, null).expr;
    }

    private TypedClickHouseExpression generateSafeScalarValue(List<ClickHouseColumn> columns, ClickHouseDataType requiredType) {
        List<ClickHouseColumn> candidateColumns = requiredType == null ? columns
                : columns.stream().filter(c -> c.getType().getType() == requiredType).collect(Collectors.toList());
        if (candidateColumns.isEmpty()) {
            if (requiredType == null) {
                throw new IgnoreMeException();
            }
            return new TypedClickHouseExpression(generateComparableConstant(requiredType), requiredType);
        }
        ClickHouseExpressionGenerator gen = new ClickHouseExpressionGenerator(state);
        List<ClickHouseColumnReference> columnRefs = candidateColumns.stream()
                .map(c -> (ClickHouseColumnReference) columnReference(c)).collect(Collectors.toList());
        for (int i = 0; i < 100; i++) {
            ClickHouseExpression expr = gen.generateExpressionWithColumns(columnRefs, 4);
            if (isSafeScalar(expr)) {
                TypedClickHouseExpression typedExpr = maybeWrapWithCast(
                        new TypedClickHouseExpression(expr, inferType(expr, candidateColumns, requiredType)),
                        requiredType);
                if (requiredType == null || typedExpr.type == requiredType) {
                    return typedExpr;
                }
            }
        }
        ClickHouseColumn fallback = Randomly.fromList(candidateColumns);
        return maybeWrapWithCast(new TypedClickHouseExpression(columnReference(fallback), fallback.getType().getType()),
                requiredType);
    }

    private boolean isSafeScalar(ClickHouseExpression expr) {
        if (expr == null) {
            return false;
        }
        if (expr instanceof ClickHouseColumnReference || expr instanceof ClickHouseConstant) {
            return true;
        }
        if (expr instanceof ClickHouseUnaryPrefixOperation) {
            return isSafeScalar(((ClickHouseUnaryPrefixOperation) expr).getExpression());
        }
        if (expr instanceof ClickHouseUnaryPostfixOperation) {
            return isSafeScalar(((ClickHouseUnaryPostfixOperation) expr).getExpression());
        }
        if (expr instanceof ClickHouseUnaryFunctionOperation) {
            return isSafeScalar(((ClickHouseUnaryFunctionOperation) expr).getExpression());
        }
        if (expr instanceof ClickHouseBinaryArithmeticOperation) {
            ClickHouseBinaryArithmeticOperation op = (ClickHouseBinaryArithmeticOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof ClickHouseBinaryFunctionOperation) {
            ClickHouseBinaryFunctionOperation op = (ClickHouseBinaryFunctionOperation) expr;
            return isSafeScalar(op.getLeft()) && isSafeScalar(op.getRight());
        }
        if (expr instanceof ClickHouseCastOperation) {
            return isSafeScalar(((ClickHouseCastOperation) expr).getExpression());
        }
        return false;
    }

    private ClickHouseDataType inferType(ClickHouseExpression expr, List<ClickHouseColumn> candidateColumns,
            ClickHouseDataType fallbackType) {
        if (fallbackType != null) {
            return fallbackType;
        }
        if (expr instanceof ClickHouseColumnReference) {
            return ((ClickHouseColumnReference) expr).getColumn().getType().getType();
        }
        if (expr instanceof ClickHouseConstant) {
            return ((ClickHouseConstant) expr).getDataType();
        }
        if (expr instanceof ClickHouseUnaryPrefixOperation) {
            return inferType(((ClickHouseUnaryPrefixOperation) expr).getExpression(), candidateColumns,
                    candidateColumns.get(0).getType().getType());
        }
        if (expr instanceof ClickHouseCastOperation) {
            return ((ClickHouseCastOperation) expr).getType();
        }
        if (expr instanceof ClickHouseUnaryFunctionOperation || expr instanceof ClickHouseBinaryArithmeticOperation
                || expr instanceof ClickHouseBinaryFunctionOperation) {
            List<ClickHouseColumn> numericColumns = candidateColumns.stream().filter(c -> isNumericType(c.getType().getType()))
                    .collect(Collectors.toList());
            if (!numericColumns.isEmpty()) {
                return numericColumns.get(0).getType().getType();
            }
        }
        return candidateColumns.get(0).getType().getType();
    }

    private boolean isNumericType(ClickHouseDataType type) {
        return List.of(ClickHouseDataType.Int8, ClickHouseDataType.Int16, ClickHouseDataType.Int32,
                ClickHouseDataType.Int64, ClickHouseDataType.UInt8, ClickHouseDataType.UInt16,
                ClickHouseDataType.UInt32, ClickHouseDataType.UInt64, ClickHouseDataType.Float32,
                ClickHouseDataType.Float64).contains(type);
    }

    private ClickHouseExpression generateLikeAtom(List<ClickHouseColumn> groupByColumns,
            TypedClickHouseExpression leftValue) {
        TypedClickHouseExpression patternValue;
        if (Randomly.getBoolean()) {
            patternValue = generateSafeScalarValue(groupByColumns, ClickHouseDataType.String);
        } else {
            patternValue = new TypedClickHouseExpression(generateLikePatternConstant(), ClickHouseDataType.String);
        }
        return new ClickHouseBinaryComparisonOperation(leftValue.expr,
                patternValue.expr, ClickHouseBinaryComparisonOperation.ClickHouseBinaryComparisonOperator.LIKE);
    }

    private ClickHouseExpression generateLikePatternConstant() {
        String base = state.getRandomly().getString();
        if (base.isEmpty()) {
            base = "a";
        }
        switch ((int) Randomly.getNotCachedInteger(0, 3)) {
        case 0:
            return new ClickHouseExpressionGenerator(state).generateConstant(new ClickHouseLancerDataType(ClickHouseDataType.String));
        case 1:
            return sqlancer.clickhouse.ast.constant.ClickHouseCreateConstant.createStringConstant("%" + base + "%");
        case 2:
            return sqlancer.clickhouse.ast.constant.ClickHouseCreateConstant.createStringConstant(base + "%");
        default:
            return sqlancer.clickhouse.ast.constant.ClickHouseCreateConstant.createStringConstant("%" + base);
        }
    }

    private TypedClickHouseExpression maybeWrapWithCast(TypedClickHouseExpression expr, ClickHouseDataType requiredType) {
        if (!Randomly.getBooleanWithRatherLowProbability()) {
            return expr;
        }
        ClickHouseDataType targetType = requiredType != null ? requiredType : chooseCastTargetType(expr.type);
        if (targetType == null || targetType == expr.type) {
            return expr;
        }
        return new TypedClickHouseExpression(new ClickHouseCastOperation(expr.expr, new ClickHouseLancerDataType(targetType)),
                targetType);
    }

    private ClickHouseDataType chooseCastTargetType(ClickHouseDataType sourceType) {
        if (sourceType == ClickHouseDataType.String) {
            return Randomly.fromOptions(ClickHouseDataType.String, ClickHouseDataType.Int32, ClickHouseDataType.Float64);
        }
        if (isNumericType(sourceType)) {
            return Randomly.fromOptions(sourceType, ClickHouseDataType.Int32, ClickHouseDataType.Float64,
                    ClickHouseDataType.String);
        }
        return sourceType;
    }

    private ClickHouseColumn getRandomColumnOfType(List<ClickHouseColumn> columns, ClickHouseDataType type) {
        List<ClickHouseColumn> matches = columns.stream().filter(c -> c.getType().getType() == type)
                .collect(Collectors.toList());
        if (matches.isEmpty()) {
            return null;
        }
        return Randomly.fromList(matches);
    }

    private ClickHouseColumn getRandomColumnOfTypes(List<ClickHouseColumn> columns, List<ClickHouseDataType> types) {
        List<ClickHouseColumn> matches = columns.stream().filter(c -> types.contains(c.getType().getType()))
                .collect(Collectors.toList());
        if (matches.isEmpty()) {
            return null;
        }
        return Randomly.fromList(matches);
    }

    private ClickHouseExpression generateComparableConstant(ClickHouseDataType type) {
        ClickHouseExpressionGenerator gen = new ClickHouseExpressionGenerator(state);
        ClickHouseLancerDataType lancerType = new ClickHouseLancerDataType(type);
        try {
            return gen.generateConstant(lancerType);
        } catch (AssertionError e) {
            if (type == ClickHouseDataType.String) {
                return gen.generateConstant(new ClickHouseLancerDataType(ClickHouseDataType.String));
            }
            return gen.generateConstant(new ClickHouseLancerDataType(ClickHouseDataType.Int32));
        }
    }

    private ClickHouseExpression columnReference(ClickHouseColumn column) {
        return new ClickHouseColumnReference(column, null, null);
    }

    private static final class TypedClickHouseExpression {
        private final ClickHouseExpression expr;
        private final ClickHouseDataType type;

        private TypedClickHouseExpression(ClickHouseExpression expr, ClickHouseDataType type) {
            this.expr = expr;
            this.type = type;
        }
    }
}
